// Sidebar.jsx
const Sidebar = ({ activeId, onChange, collapsed, onToggle }) => {
  const modules = window.OB_MODULES;
  return (
    <aside style={{
      width: collapsed ? 56 : 228,
      flexShrink: 0,
      background: "var(--sidebar-bg)",
      borderRight: "1px solid var(--sidebar-border)",
      height: "100vh",
      position: "sticky",
      top: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      transition: "width var(--transition-slow)",
    }}>
      {/* Brand */}
      <div style={{
        padding: collapsed ? "16px 8px" : "18px 14px 14px",
        borderBottom: "1px solid var(--sidebar-border)",
        display: "flex", alignItems: "center", justifyContent: collapsed ? "center" : "space-between", gap: 10,
        flexShrink: 0,
      }}>
        {!collapsed && (
          <div style={{display:"flex",alignItems:"center",gap:10,overflow:"hidden"}}>
            <div style={{ width:30, height:30, borderRadius:"var(--radius-md)", background:"var(--hr-gradient)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
              <Icon name="layers" size={15} color="white"/>
            </div>
            <div>
              <div style={{fontSize:13, fontWeight:700, color:"var(--text-inverse)", letterSpacing:"-0.01em"}}>OfferBerries</div>
              <div style={{fontSize:10, color:"var(--sidebar-section)", fontWeight:600, letterSpacing:".06em", textTransform:"uppercase"}}>ERP Suite</div>
            </div>
          </div>
        )}
        {collapsed && (
          <div style={{ width:30, height:30, borderRadius:"var(--radius-md)", background:"var(--hr-gradient)", display:"flex", alignItems:"center", justifyContent:"center" }}>
            <Icon name="layers" size={15} color="white"/>
          </div>
        )}
        {!collapsed && (
          <button onClick={onToggle} style={{ background:"none", border:"none", cursor:"pointer", color:"var(--sidebar-text)", padding:4, display:"flex" }}>
            <Icon name="chevL" size={16}/>
          </button>
        )}
      </div>

      {/* Body */}
      <div style={{ flex:1, overflowY:"auto", padding: 8 }}>
        {!collapsed && (
          <div style={{ fontSize:10, fontWeight:700, color:"var(--sidebar-section)", textTransform:"uppercase", letterSpacing:".1em", padding:"8px 8px 4px" }}>
            Menu
          </div>
        )}
        {modules.map(m => {
          const active = m.id === activeId;
          return (
            <button key={m.id} onClick={() => onChange(m.id)} title={collapsed ? m.name : undefined}
              style={{
                display:"flex", alignItems:"center", gap: collapsed ? 0 : 10,
                justifyContent: collapsed ? "center" : "flex-start",
                width:"100%", padding: collapsed ? "10px 0" : "9px 10px",
                borderRadius:"var(--radius-md)",
                border:"none", borderLeft: active ? "2px solid var(--sidebar-active-bar)" : "2px solid transparent",
                paddingLeft: collapsed ? 0 : (active ? 8 : 10),
                cursor:"pointer",
                background: active ? "var(--sidebar-active-bg)" : "transparent",
                color: active ? "var(--sidebar-text-active)" : "var(--sidebar-text)",
                fontSize:13, fontWeight: active ? 600 : 500,
                textAlign:"left", marginBottom:2, transition:"all var(--transition-fast)",
              }}
              onMouseEnter={e=>{ if(!active){ e.currentTarget.style.background="rgba(255,255,255,.05)"; e.currentTarget.style.color="var(--sidebar-text-hover)";} }}
              onMouseLeave={e=>{ if(!active){ e.currentTarget.style.background="transparent"; e.currentTarget.style.color="var(--sidebar-text)";} }}
            >
              <Icon name={m.icon} size={15}/>
              {!collapsed && <span style={{whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis"}}>{m.name}</span>}
            </button>
          );
        })}

        {!collapsed && (
          <>
            <div style={{ fontSize:10, fontWeight:700, color:"var(--sidebar-section)", textTransform:"uppercase", letterSpacing:".1em", padding:"16px 8px 4px" }}>
              Quick links
            </div>
            {[
              { name: "Drafts", icon: "file" },
              { name: "Approvals", icon: "check" },
              { name: "Reports", icon: "trend" },
              { name: "Calendar", icon: "calendar" },
            ].map(q => (
              <div key={q.name} style={{
                display:"flex", alignItems:"center", gap:10, padding:"7px 10px", margin:"1px 0",
                borderRadius:"var(--radius-md)", color:"var(--sidebar-text)", fontSize:12, fontWeight:500,
                cursor:"pointer"
              }}
              onMouseEnter={e=>{ e.currentTarget.style.background="rgba(255,255,255,.04)"; }}
              onMouseLeave={e=>{ e.currentTarget.style.background="transparent"; }}
              >
                <Icon name={q.icon} size={13}/>{q.name}
              </div>
            ))}
          </>
        )}
      </div>

      {/* Footer */}
      <div style={{
        padding: collapsed ? "12px 8px" : "12px 14px",
        borderTop:"1px solid var(--sidebar-border)",
        display:"flex", alignItems:"center", justifyContent: collapsed ? "center" : "space-between",
      }}>
        {collapsed ? (
          <button onClick={onToggle} style={{background:"none",border:"none",cursor:"pointer",color:"var(--sidebar-text)",display:"flex"}}>
            <Icon name="chevR" size={16}/>
          </button>
        ) : (
          <p style={{fontSize:10, color:"var(--sidebar-section)", fontWeight:600, textTransform:"uppercase", letterSpacing:".06em", margin:0}}>
            Enterprise v2.0
          </p>
        )}
      </div>
    </aside>
  );
};
window.Sidebar = Sidebar;
