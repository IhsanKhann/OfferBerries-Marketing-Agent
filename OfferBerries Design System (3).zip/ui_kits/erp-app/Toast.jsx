// Toast.jsx
const Toast = ({ toast, onDismiss }) => {
  if (!toast) return null;
  const iconMap = { success: "check", warning: "alert", danger: "x", info: "info" };
  const colorMap = { success: "var(--success)", warning: "var(--warning)", danger: "var(--danger)", info: "var(--info)" };
  return (
    <div style={{
      position:"fixed", bottom:24, right:24, zIndex:"var(--z-toast)",
      animation: "erp-slide-up 250ms cubic-bezier(0.4, 0, 0.2, 1) both",
    }}>
      <div className={`erp-toast erp-toast-${toast.kind}`}>
        <div style={{ width:28, height:28, borderRadius:"50%", background:`${colorMap[toast.kind]}1A`, color: colorMap[toast.kind], display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0}}>
          <Icon name={iconMap[toast.kind]} size={14}/>
        </div>
        <div style={{flex:1}}>
          <div style={{fontWeight:500, color:"var(--text-primary)", fontSize:13}}>{toast.title}</div>
          {toast.body && <div style={{color:"var(--text-secondary)", fontSize:12, marginTop:2}}>{toast.body}</div>}
        </div>
        <button onClick={onDismiss} style={{background:"none",border:"none",cursor:"pointer",color:"var(--text-muted)",padding:0,display:"flex"}}>
          <Icon name="x" size={13}/>
        </button>
      </div>
    </div>
  );
};
window.Toast = Toast;
