# OfferBerries ERP — UI Kit

A React (CDN + Babel) prototype of the OfferBerries ERP app shell. Switch modules using the sidebar; each module has its own gradient hero, KPI cards, and a representative table.

## Files
- `index.html` — entry; wires React + Babel and renders `<App/>`
- `Sidebar.jsx` — persistent dark `#0F172A` sidebar with org sections and active states
- `Topbar.jsx` — 58px topbar with breadcrumb, global search, module switch, avatar
- `ModuleHero.jsx` — gradient strip + page title + actions
- `StatCard.jsx` — KPI card with module-tinted icon
- `DataTable.jsx` — Supabase-density table with badges
- `Modal.jsx` — modal shell + form pattern
- `Toast.jsx` — toast notification
- `data.js` — sample employees, sellers, statements
- `App.jsx` — composes everything; manages active module + modal state

## How to view
Open `index.html` directly. No build step.

## How to copy into production
Tokens live in the project root at `colors_and_type.css` — import it once globally. The Tailwind config in the source repo (`frontend/tailwind.config.js`) maps these tokens 1:1, so the same class names work whether you're using Tailwind or plain CSS classes (`.erp-btn-hr`, `.erp-badge-approved`, etc.).
