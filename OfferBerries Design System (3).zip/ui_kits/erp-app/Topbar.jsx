// Topbar.jsx
const Topbar = ({ module, breadcrumb, onNewClick }) => {
  return (
    <header style={{
      height: "var(--topbar-height)",
      background: "var(--topbar-bg)",
      borderBottom: "1px solid var(--topbar-border)",
      display: "flex",
      alignItems: "center",
      padding: "0 24px",
      gap: 20,
      position: "sticky", top: 0, zIndex: 10,
    }}>
      {/* Breadcrumb */}
      <div style={{display:"flex", alignItems:"center", gap:8, fontSize:13, color:"var(--text-secondary)"}}>
        <span style={{color:"var(--text-muted)"}}>{module}</span>
        <Icon name="chevR" size={12} color="var(--text-muted)"/>
        <span style={{color:"var(--text-primary)", fontWeight:500}}>{breadcrumb}</span>
      </div>

      {/* Search */}
      <div style={{
        flex:1, maxWidth:480, marginLeft:"auto",
        display:"flex", alignItems:"center", gap:8,
        background:"var(--bg-page)", border:"1px solid var(--border-default)",
        borderRadius:"var(--radius-md)", padding:"7px 12px",
      }}>
        <Icon name="search" size={14} color="var(--text-muted)"/>
        <input placeholder="Search employees, sellers, statements…"
          style={{
            border:"none", background:"transparent", outline:"none",
            flex:1, fontSize:13, fontFamily:"inherit", color:"var(--text-primary)",
          }}/>
        <kbd style={{
          fontSize:10, fontFamily:"var(--font-mono)", color:"var(--text-muted)",
          background:"var(--bg-canvas)", border:"1px solid var(--border-default)",
          borderRadius:4, padding:"1px 6px"
        }}>⌘K</kbd>
      </div>

      {/* Actions */}
      <button className="erp-btn erp-btn-icon" aria-label="notifications" style={{position:"relative"}}>
        <Icon name="bell" size={15}/>
        <span style={{position:"absolute", top:6, right:7, width:7, height:7, borderRadius:"50%", background:"var(--danger)", border:"1.5px solid var(--bg-canvas)"}}/>
      </button>
      <button className="erp-btn erp-btn-icon" aria-label="settings"><Icon name="settings" size={15}/></button>

      <button className="erp-btn erp-btn-primary" onClick={onNewClick}>
        <Icon name="plus" size={14}/> New record
      </button>

      <div style={{display:"flex", alignItems:"center", gap:10, paddingLeft:8, borderLeft:"1px solid var(--border-default)", height:32}}>
        <div className="erp-avatar" style={{width:32, height:32, fontSize:12}}>HM</div>
        <div style={{lineHeight:1.2}}>
          <div style={{fontSize:12, fontWeight:500, color:"var(--text-primary)"}}>Hassan Mahmood</div>
          <div style={{fontSize:10, color:"var(--text-muted)"}}>Finance Admin</div>
        </div>
      </div>
    </header>
  );
};
window.Topbar = Topbar;
