// ModuleHero.jsx — gradient strip + title + summary
const ModuleHero = ({ module, title, subtitle, stats }) => (
  <div style={{
    background: module.gradient,
    borderRadius: "var(--radius-xl)",
    padding: "22px 26px",
    color: "white",
    position: "relative",
    overflow: "hidden",
    marginBottom: 20,
  }}>
    <div style={{position:"absolute", top:-30, right:-30, width:140, height:140, borderRadius:"50%", background:"rgba(255,255,255,.08)", pointerEvents:"none"}}/>
    <div style={{position:"absolute", bottom:-20, left:-20, width:70, height:70, borderRadius:"50%", background:"rgba(255,255,255,.05)", pointerEvents:"none"}}/>
    <div style={{position:"relative", display:"flex", justifyContent:"space-between", alignItems:"flex-end", gap:24}}>
      <div>
        <div style={{fontSize:11, fontWeight:600, letterSpacing:".08em", textTransform:"uppercase", opacity:.85}}>{module.name}</div>
        <div style={{fontSize:28, fontWeight:500, marginTop:4, letterSpacing:"-0.01em"}}>{title}</div>
        <div style={{fontSize:13, marginTop:6, opacity:.85, maxWidth:560}}>{subtitle}</div>
      </div>
      {stats && (
        <div style={{display:"flex", gap:28}}>
          {stats.map((s,i)=>(
            <div key={i}>
              <div style={{fontSize:11, fontWeight:600, letterSpacing:".06em", textTransform:"uppercase", opacity:.8}}>{s.label}</div>
              <div style={{fontSize:22, fontWeight:500, marginTop:2, fontFamily: s.mono ? "var(--font-mono)" : "inherit"}}>{s.value}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  </div>
);
window.ModuleHero = ModuleHero;
