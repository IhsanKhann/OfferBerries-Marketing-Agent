// data.js — sample fixtures
window.OB_DATA = {
  employees: [
    { id: "EMP-04219", name: "Asad Rauf",     dept: "Finance",       status: "approved",  net: "PKR 184,000", avatar: "AR", tint: ["#EEF2FF","#3730A3"] },
    { id: "EMP-04220", name: "Nimra Khan",    dept: "HR",            status: "pending",   net: "PKR 142,500", avatar: "NK", tint: ["#FEF3C7","#92400E"] },
    { id: "EMP-04221", name: "Usman Haider",  dept: "Business Ops",  status: "paid",      net: "PKR 220,000", avatar: "UH", tint: ["#DCFCE7","#166534"] },
    { id: "EMP-04222", name: "Sana Farooq",   dept: "Compliance",    status: "suspended", net: "PKR 95,000",  avatar: "SF", tint: ["#FFE4E6","#9F1239"] },
    { id: "EMP-04223", name: "Bilal Anwar",   dept: "Finance",       status: "approved",  net: "PKR 168,500", avatar: "BA", tint: ["#DBEAFE","#1E40AF"] },
    { id: "EMP-04224", name: "Hira Mansoor",  dept: "Business Ops",  status: "draft",     net: "PKR 110,000", avatar: "HM", tint: ["#FED7AA","#9A3412"] },
    { id: "EMP-04225", name: "Talha Sajid",   dept: "IT",            status: "approved",  net: "PKR 198,000", avatar: "TS", tint: ["#CFFAFE","#155E75"] },
  ],
  sellers: [
    { id: "SLR-1042", name: "Lahore Linens Co.",   reg: "08 May 2026", category: "Home & Living",  status: "approved",  gmv: "PKR 4.2M"   },
    { id: "SLR-1043", name: "Karachi Tech Hub",    reg: "11 May 2026", category: "Electronics",    status: "pending",   gmv: "PKR 1.8M"   },
    { id: "SLR-1044", name: "Islamabad Imports",   reg: "14 May 2026", category: "Cosmetics",      status: "rejected",  gmv: "—"          },
    { id: "SLR-1045", name: "Faisal Fabrics",      reg: "19 May 2026", category: "Apparel",        status: "approved",  gmv: "PKR 12.1M"  },
    { id: "SLR-1046", name: "Multan Mango Mart",   reg: "22 May 2026", category: "Groceries",      status: "draft",     gmv: "PKR 0.4M"   },
    { id: "SLR-1047", name: "Peshawar Plastics",   reg: "24 May 2026", category: "Industrial",     status: "pending",   gmv: "PKR 2.7M"   },
  ],
  statements: [
    { id: "ST-2419", date: "27 May 2026", buyer: "Lahore Linens Co.", seller: "Faisal Fabrics",   amount: "PKR 84,500",  status: "paid"     },
    { id: "ST-2420", date: "27 May 2026", buyer: "Karachi Tech Hub",  seller: "Islamabad Imports",amount: "PKR 218,000", status: "pending"  },
    { id: "ST-2421", date: "26 May 2026", buyer: "Faisal Fabrics",    seller: "Multan Mango Mart",amount: "PKR 11,200",  status: "approved" },
    { id: "ST-2422", date: "26 May 2026", buyer: "Peshawar Plastics", seller: "Karachi Tech Hub", amount: "PKR 64,750",  status: "rejected" },
    { id: "ST-2423", date: "25 May 2026", buyer: "Lahore Linens Co.", seller: "Faisal Fabrics",   amount: "PKR 132,400", status: "paid"     },
  ],
};

// Module config (must mirror tokens.css)
window.OB_MODULES = [
  { id: "workspace",  name: "My Workspace",        accent: "hr",  gradient: "linear-gradient(135deg,#4F46E5,#7C3AED)", icon: "grid"     },
  { id: "hr",         name: "HR & Administration", accent: "hr",  gradient: "linear-gradient(135deg,#4F46E5,#7C3AED)", icon: "users"    },
  { id: "finance",    name: "Finance & Accounting",accent: "fin", gradient: "linear-gradient(135deg,#0EA5E9,#10B981)", icon: "wallet"   },
  { id: "ops",        name: "Business Operations", accent: "ops", gradient: "linear-gradient(135deg,#F97316,#F59E0B)", icon: "shop"     },
  { id: "governance", name: "Corporate Governance",accent: "gov", gradient: "linear-gradient(135deg,#334155,#10B981)", icon: "shield"   },
];
