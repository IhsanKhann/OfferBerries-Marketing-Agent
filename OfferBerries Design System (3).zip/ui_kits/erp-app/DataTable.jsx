// DataTable.jsx
const DataTable = ({ title, columns, rows, action, footer }) => (
  <div style={{
    background: "var(--bg-canvas)",
    border: "1px solid var(--border-default)",
    borderRadius: "var(--radius-lg)",
    overflow: "hidden",
    boxShadow: "var(--shadow-xs)",
  }}>
    {(title || action) && (
      <div style={{
        display:"flex", justifyContent:"space-between", alignItems:"center",
        padding:"14px 18px", borderBottom:"1px solid var(--border-subtle)",
      }}>
        <div>
          <div style={{fontSize:15, fontWeight:500, color:"var(--text-primary)"}}>{title}</div>
        </div>
        <div style={{display:"flex", gap:8}}>
          <button className="erp-btn erp-btn-ghost erp-btn-sm">
            <Icon name="filter" size={12}/> Filter
          </button>
          <button className="erp-btn erp-btn-ghost erp-btn-sm">
            <Icon name="download" size={12}/> Export
          </button>
          {action}
        </div>
      </div>
    )}
    <div style={{overflowX:"auto"}}>
      <table className="erp-table">
        <thead><tr>
          {columns.map(c => <th key={c.key} style={{textAlign: c.align || "left"}}>{c.label}</th>)}
        </tr></thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              {columns.map(c => (
                <td key={c.key} style={{
                  textAlign: c.align || "left",
                  fontFamily: c.mono ? "var(--font-mono)" : undefined,
                  color: c.mono ? "var(--text-secondary)" : undefined,
                  whiteSpace: c.nowrap ? "nowrap" : undefined,
                }}>
                  {c.render ? c.render(r) : r[c.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    {footer && (
      <div style={{
        display:"flex", justifyContent:"space-between", alignItems:"center",
        padding:"10px 18px", borderTop:"1px solid var(--border-subtle)",
        fontSize:12, color:"var(--text-muted)",
      }}>{footer}</div>
    )}
  </div>
);
window.DataTable = DataTable;

// Badge helper
const Badge = ({ status }) => <span className={`erp-badge erp-badge-${status}`}>{status[0].toUpperCase()+status.slice(1)}</span>;
window.Badge = Badge;

// Avatar helper
const Avatar = ({ name, tint = ["#EEF2FF","#3730A3"], initials, size = 26 }) => (
  <span style={{
    width:size, height:size, borderRadius:"50%",
    background: tint[0], color: tint[1],
    display:"inline-flex", alignItems:"center", justifyContent:"center",
    fontSize: Math.round(size*0.4), fontWeight:600, flexShrink:0, marginRight:10, verticalAlign:"middle",
  }}>{initials || name?.split(" ").map(s=>s[0]).slice(0,2).join("")}</span>
);
window.Avatar = Avatar;
