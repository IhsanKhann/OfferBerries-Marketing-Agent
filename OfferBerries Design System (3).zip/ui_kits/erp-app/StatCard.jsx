// StatCard.jsx
const StatCard = ({ label, value, trend, trendDir, icon, gradient }) => (
  <div className="erp-stat-card" style={{padding:18}}>
    <div style={{display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:10}}>
      <div className="erp-stat-label" style={{fontSize:11, letterSpacing:".07em", textTransform:"uppercase"}}>{label}</div>
      <div style={{ width:36, height:36, borderRadius:"var(--radius-md)", background: gradient, display:"flex", alignItems:"center", justifyContent:"center", color:"white", flexShrink:0 }}>
        <Icon name={icon} size={17}/>
      </div>
    </div>
    <div className="erp-stat-value" style={{fontSize:28, letterSpacing:"-0.01em"}}>{value}</div>
    {trend && (
      <div className={`erp-stat-trend erp-stat-trend-${trendDir || "flat"}`} style={{fontSize:11}}>
        {trendDir === "up" ? "▲" : trendDir === "down" ? "▼" : "—"} {trend}
      </div>
    )}
  </div>
);
window.StatCard = StatCard;
