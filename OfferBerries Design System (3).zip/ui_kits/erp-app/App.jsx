// App.jsx — composes the full ERP shell
const { useState } = React;

const moduleConfig = {
  workspace: {
    title: "Good evening, Hassan",
    subtitle: "5 items need your action today. Last sync 12 minutes ago.",
    stats: [
      { label: "Pending approvals", value: "5", mono: false },
      { label: "Drafts",            value: "2", mono: false },
    ],
    kpis: [
      { label: "Inbox",              value: "12",       icon: "inbox",    trend: "3 new today",          dir: "up"   },
      { label: "Assigned tasks",     value: "8",        icon: "check",    trend: "2 due this week",      dir: "flat" },
      { label: "Drafts saved",       value: "2",        icon: "file",     trend: "Auto-saved 11 min",    dir: "flat" },
      { label: "Reports generated",  value: "47",       icon: "trend",    trend: "May 2026",             dir: "flat" },
    ],
    tableTitle: "My recent activity",
    tableKind: "activity",
  },
  hr: {
    title: "Payroll for May 2026",
    subtitle: "1,284 active employees across 7 departments. Payroll closes 30 May at 17:00 PKT.",
    stats: [
      { label: "Active",       value: "1,284" },
      { label: "Leave today",  value: "23"    },
      { label: "Open reqs",    value: "8"     },
    ],
    kpis: [
      { label: "Active employees", value: "1,284",    icon: "users",  trend: "+4.2% vs last month",  dir: "up"   },
      { label: "On leave",         value: "23",       icon: "calendar", trend: "8 unplanned",         dir: "flat" },
      { label: "Pending approvals",value: "12",       icon: "check",  trend: "Oldest: 3 days",       dir: "flat" },
      { label: "Open requisitions",value: "8",        icon: "file",   trend: "2 closing soon",       dir: "down" },
    ],
    tableTitle: "Employees · Payroll review",
    tableKind: "employees",
  },
  finance: {
    title: "Outstanding ledger · May 2026",
    subtitle: "PKR 84.2M processed in payroll. 37 account statements awaiting reconciliation.",
    stats: [
      { label: "Payroll",      value: "PKR 84.2M", mono: true },
      { label: "Receivable",   value: "PKR 41.6M", mono: true },
      { label: "Payable",      value: "PKR 18.9M", mono: true },
    ],
    kpis: [
      { label: "Payroll · May",   value: "PKR 84.2M",  icon: "wallet", trend: "Processed 28 May", dir: "flat" },
      { label: "Receivable",      value: "PKR 41.6M",  icon: "trend",  trend: "+12% vs Apr",      dir: "up"   },
      { label: "Pending statements", value: "37",      icon: "file",   trend: "Oldest: 6 days",   dir: "flat" },
      { label: "Reconciled",      value: "412",        icon: "check",  trend: "This month",       dir: "up"   },
    ],
    tableTitle: "Account statements",
    tableKind: "statements",
  },
  ops: {
    title: "Marketplace operations",
    subtitle: "812 active sellers · 37 awaiting onboarding review. Disputes SLA at 94% this week.",
    stats: [
      { label: "Active sellers", value: "812" },
      { label: "Pending review", value: "37"  },
      { label: "Disputes",       value: "14"  },
    ],
    kpis: [
      { label: "Active sellers",   value: "812",       icon: "shop",   trend: "+18 this week",     dir: "up"   },
      { label: "Pending review",   value: "37",        icon: "alert",  trend: "12 over SLA",        dir: "down" },
      { label: "GMV · May",        value: "PKR 1.42B", icon: "trend",  trend: "+8% vs Apr",        dir: "up"   },
      { label: "Open disputes",    value: "14",        icon: "info",   trend: "SLA 94%",            dir: "flat" },
    ],
    tableTitle: "Sellers · Onboarding queue",
    tableKind: "sellers",
  },
  governance: {
    title: "Compliance & audit",
    subtitle: "Q2 2026 audit cycle in progress. 4 policies pending board review.",
    stats: [
      { label: "Policies",      value: "127" },
      { label: "Open audits",   value: "4"   },
      { label: "Incidents",     value: "0"   },
    ],
    kpis: [
      { label: "Policies",          value: "127", icon: "shield", trend: "4 pending board",    dir: "flat" },
      { label: "Open audits",       value: "4",   icon: "file",   trend: "Q2 cycle",            dir: "flat" },
      { label: "Compliance score",  value: "98%", icon: "check",  trend: "+2% vs Q1",          dir: "up"   },
      { label: "Incidents · 30d",   value: "0",   icon: "alert",  trend: "Clean record",        dir: "up"   },
    ],
    tableTitle: "Audit log · last 48 hours",
    tableKind: "audit",
  },
};

const App = () => {
  const [activeMod, setActiveMod] = useState("hr");
  const [collapsed, setCollapsed] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [toast, setToast] = useState(null);

  const module = window.OB_MODULES.find(m => m.id === activeMod);
  const cfg    = moduleConfig[activeMod];

  // Build table based on the active module
  const tables = {
    employees: {
      columns: [
        { key:"name",   label:"Employee",   render: r => <><Avatar name={r.name} tint={r.tint}/>{r.name}</> },
        { key:"id",     label:"Code",       mono:true, nowrap:true },
        { key:"dept",   label:"Department" },
        { key:"status", label:"Status",     render: r => <Badge status={r.status}/> },
        { key:"net",    label:"Net salary", align:"right", mono:true, nowrap:true },
      ],
      rows: window.OB_DATA.employees,
    },
    sellers: {
      columns: [
        { key:"name",     label:"Seller" },
        { key:"id",       label:"Code",       mono:true, nowrap:true },
        { key:"category", label:"Category" },
        { key:"reg",      label:"Registered", mono:true, nowrap:true },
        { key:"status",   label:"Status",     render: r => <Badge status={r.status}/> },
        { key:"gmv",      label:"GMV · May",  align:"right", mono:true },
      ],
      rows: window.OB_DATA.sellers,
    },
    statements: {
      columns: [
        { key:"id",     label:"Statement", mono:true, nowrap:true },
        { key:"date",   label:"Date",      mono:true, nowrap:true },
        { key:"buyer",  label:"Buyer" },
        { key:"seller", label:"Seller" },
        { key:"amount", label:"Amount",    align:"right", mono:true },
        { key:"status", label:"Status",    render: r => <Badge status={r.status}/> },
      ],
      rows: window.OB_DATA.statements,
    },
    activity: {
      columns: [
        { key:"time",   label:"Time",   mono:true, nowrap:true },
        { key:"event",  label:"Event" },
        { key:"actor",  label:"Actor" },
        { key:"status", label:"Status", render: r => <Badge status={r.status}/> },
      ],
      rows: [
        { time:"17:42", event:"Approved statement ST-2419",   actor:"You",            status:"approved" },
        { time:"15:08", event:"Saved draft · Payroll May",     actor:"You",            status:"draft"    },
        { time:"12:31", event:"Rejected seller SLR-1044",      actor:"You",            status:"rejected" },
        { time:"09:14", event:"Payroll batch closed",          actor:"System",         status:"paid"     },
      ],
    },
    audit: {
      columns: [
        { key:"time",  label:"Time", mono:true, nowrap:true },
        { key:"actor", label:"Actor" },
        { key:"action",label:"Action" },
        { key:"object",label:"Object", mono:true, nowrap:true },
        { key:"result",label:"Result", render: r => <Badge status={r.result}/> },
      ],
      rows: [
        { time:"28 May · 17:42", actor:"Hassan Mahmood",  action:"Approved payment",   object:"ST-2419",   result:"approved" },
        { time:"28 May · 16:10", actor:"System",          action:"Policy sync",        object:"POL-118",   result:"paid"     },
        { time:"28 May · 12:31", actor:"Nimra Khan",      action:"Rejected onboarding",object:"SLR-1044",  result:"rejected" },
        { time:"28 May · 09:14", actor:"Asad Rauf",       action:"Closed audit",       object:"AUD-Q2-03", result:"approved" },
        { time:"27 May · 22:08", actor:"System",          action:"Suspended user",     object:"EMP-04222", result:"suspended"},
      ],
    },
  };

  const tbl = tables[cfg.tableKind];

  const fireToast = (kind, title, body) => {
    setToast({ kind, title, body });
    setTimeout(() => setToast(null), 4200);
  };

  return (
    <div style={{display:"flex", minHeight:"100vh", background:"var(--bg-page)"}}>
      <Sidebar activeId={activeMod} onChange={setActiveMod}
               collapsed={collapsed} onToggle={() => setCollapsed(c => !c)}/>

      <main style={{flex:1, minWidth:0, display:"flex", flexDirection:"column"}}>
        <Topbar module={module.name} breadcrumb={cfg.title.split(" · ")[0]}
                onNewClick={() => setModalOpen(true)}/>

        <div style={{flex:1, overflowY:"auto", padding:24}}>
          <div style={{maxWidth:1400, margin:"0 auto"}}>
            <ModuleHero module={module} title={cfg.title} subtitle={cfg.subtitle} stats={cfg.stats}/>

            <div style={{display:"grid", gridTemplateColumns:"repeat(4, 1fr)", gap:14, marginBottom:24}}>
              {cfg.kpis.map((k, i) => (
                <StatCard key={i} label={k.label} value={k.value} icon={k.icon}
                          gradient={module.gradient} trend={k.trend} trendDir={k.dir}/>
              ))}
            </div>

            <DataTable
              title={cfg.tableTitle}
              columns={tbl.columns}
              rows={tbl.rows}
              footer={
                <>
                  <span>Showing 1–{tbl.rows.length} of {tbl.rows.length}</span>
                  <div style={{display:"flex", gap:6, alignItems:"center"}}>
                    <button className="erp-btn erp-btn-ghost erp-btn-sm" disabled><Icon name="chevL" size={11}/></button>
                    <span style={{fontFamily:"var(--font-mono)"}}>1 / 1</span>
                    <button className="erp-btn erp-btn-ghost erp-btn-sm" disabled><Icon name="chevR" size={11}/></button>
                  </div>
                </>
              }
            />

            <div style={{display:"grid", gridTemplateColumns:"2fr 1fr", gap:14, marginTop:24}}>
              <div className="erp-card" style={{padding:20}}>
                <div className="erp-section-header" style={{marginBottom:14}}>
                  <div className="erp-section-title">Activity timeline</div>
                  <span className="erp-section-action">View all</span>
                </div>
                {[
                  { t:"17:42", a:"Hassan Mahmood",  v:"Approved payment ST-2419", k:"approved" },
                  { t:"15:08", a:"You",             v:"Saved draft · Payroll May", k:"draft"    },
                  { t:"12:31", a:"Nimra Khan",      v:"Rejected seller SLR-1044", k:"rejected" },
                  { t:"09:14", a:"System",          v:"Payroll batch closed",     k:"paid"     },
                ].map((e,i)=>(
                  <div key={i} style={{display:"flex", alignItems:"center", gap:14, padding:"10px 0", borderBottom: i<3 ? "1px solid var(--border-subtle)" : "none"}}>
                    <div style={{fontFamily:"var(--font-mono)", fontSize:11, color:"var(--text-muted)", width:48, flexShrink:0}}>{e.t}</div>
                    <div style={{flex:1, fontSize:13, color:"var(--text-primary)"}}>{e.v}</div>
                    <div style={{fontSize:12, color:"var(--text-secondary)", width:130}}>{e.a}</div>
                    <Badge status={e.k}/>
                  </div>
                ))}
              </div>

              <div className="erp-card" style={{padding:20}}>
                <div className="erp-section-header" style={{marginBottom:14}}>
                  <div className="erp-section-title">Quick actions</div>
                </div>
                <div style={{display:"flex", flexDirection:"column", gap:8}}>
                  <button className="erp-btn erp-btn-outline" style={{justifyContent:"flex-start", padding:"10px 14px"}}
                          onClick={() => fireToast("success","Statement #ST-2419 paid","PKR 84,500 transferred")}>
                    <Icon name="check" size={14}/> Approve next pending
                  </button>
                  <button className="erp-btn erp-btn-ghost" style={{justifyContent:"flex-start", padding:"10px 14px"}}
                          onClick={() => fireToast("info","Export queued","CSV will be ready in ~30s")}>
                    <Icon name="download" size={14}/> Export this view
                  </button>
                  <button className="erp-btn erp-btn-ghost" style={{justifyContent:"flex-start", padding:"10px 14px"}}
                          onClick={() => fireToast("warning","3 sellers awaiting review","Oldest submission: 4 days ago")}>
                    <Icon name="alert" size={14}/> Check SLA breaches
                  </button>
                  <button className="erp-btn erp-btn-ghost" style={{justifyContent:"flex-start", padding:"10px 14px"}}
                          onClick={() => setModalOpen(true)}>
                    <Icon name="plus" size={14}/> New record
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)}
        title="Create new record" subtitle="Choose a type and fill in the basics. You can save as draft."
        footer={<>
          <button className="erp-btn erp-btn-ghost" onClick={() => setModalOpen(false)}>Cancel</button>
          <button className="erp-btn erp-btn-ghost" onClick={() => { setModalOpen(false); fireToast("info","Draft saved","Auto-saved to your workspace"); }}>Save draft</button>
          <button className="erp-btn erp-btn-primary"
                  onClick={() => { setModalOpen(false); fireToast("success","Record created","Now visible in the queue"); }}>
            Create record
          </button>
        </>}>
        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:14}}>
          <FormRow label="Record type" required>
            <select className="erp-input">
              <option>Employee</option><option>Seller</option><option>Statement</option><option>Leave request</option>
            </select>
          </FormRow>
          <FormRow label="Department" required>
            <select className="erp-input">
              <option>HR</option><option>Finance</option><option>Business Ops</option><option>Compliance</option>
            </select>
          </FormRow>
          <FormRow label="Full name" required>
            <input className="erp-input" placeholder="e.g. Asad Rauf"/>
          </FormRow>
          <FormRow label="CNIC" required hint="13 digits, format auto-applied">
            <input className="erp-input" placeholder="42101-XXXXXXX-X"/>
          </FormRow>
          <FormRow label="Joining date">
            <input className="erp-input" type="date" defaultValue="2026-05-28"/>
          </FormRow>
          <FormRow label="Reporting to">
            <input className="erp-input" placeholder="Search employee…"/>
          </FormRow>
          <div style={{gridColumn:"1 / -1"}}>
            <FormRow label="Notes">
              <textarea className="erp-input" rows="3" placeholder="Internal notes (visible to HR only)…"/>
            </FormRow>
          </div>
        </div>
      </Modal>

      <Toast toast={toast} onDismiss={() => setToast(null)}/>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
