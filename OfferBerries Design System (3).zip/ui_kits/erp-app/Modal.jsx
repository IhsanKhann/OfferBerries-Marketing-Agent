// Modal.jsx
const Modal = ({ open, onClose, title, subtitle, children, footer }) => {
  if (!open) return null;
  return (
    <div className="erp-modal-overlay" onClick={onClose} style={{animation:"erp-fade-in 200ms ease-out both"}}>
      <div className="erp-modal erp-modal-lg" onClick={e=>e.stopPropagation()}
        style={{padding:0, animation:"erp-scale-in 250ms cubic-bezier(0.34, 1.56, 0.64, 1) both"}}>
        <div style={{display:"flex", justifyContent:"space-between", alignItems:"flex-start", padding:"22px 24px 14px", borderBottom:"1px solid var(--border-subtle)"}}>
          <div>
            <div style={{fontSize:18, fontWeight:500, color:"var(--text-primary)"}}>{title}</div>
            {subtitle && <div style={{fontSize:13, color:"var(--text-secondary)", marginTop:4}}>{subtitle}</div>}
          </div>
          <button className="erp-btn erp-btn-icon" onClick={onClose}><Icon name="x" size={15}/></button>
        </div>
        <div style={{padding:"20px 24px"}}>{children}</div>
        {footer && (
          <div style={{display:"flex", justifyContent:"flex-end", gap:10, padding:"14px 24px", borderTop:"1px solid var(--border-subtle)", background:"var(--bg-page)"}}>
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};
window.Modal = Modal;

// FormRow helper
const FormRow = ({ label, required, hint, error, children }) => (
  <div className="erp-field" style={{marginBottom: 14}}>
    <label className="erp-field-label">{label}{required && <span className="erp-required">*</span>}</label>
    {children}
    {hint && !error && <span className="erp-field-hint">{hint}</span>}
    {error && <span className="erp-field-error">{error}</span>}
  </div>
);
window.FormRow = FormRow;
