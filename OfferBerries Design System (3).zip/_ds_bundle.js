/* @ds-bundle: {"format":3,"namespace":"OfferBerriesDesignSystem_cc94b3","components":[{"name":"DashboardLayout","sourcePath":"frontend/src/components/layouts/DashboardLayout.jsx"},{"name":"Sidebar","sourcePath":"frontend/src/components/layouts/Sidebar.jsx"},{"name":"Button","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"Badge","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"Input","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"Select","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"Textarea","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"Card","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"ModuleCard","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"StatCard","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"Avatar","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"Modal","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"Dropdown","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"Table","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"Loader","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"SectionHeader","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"DynamicFieldSection","sourcePath":"frontend/src/components/ui/index.jsx"},{"name":"ICON_FOR","sourcePath":"toast-system/toast-variants.ts"}],"sourceHashes":{"frontend/src/components/layouts/DashboardLayout.jsx":"a9857b4c50fd","frontend/src/components/layouts/Sidebar.jsx":"4db0105cd0da","frontend/src/components/ui/index.jsx":"a53b059b5577","toast-system/toast-variants.ts":"bfccc1163bc6","ui_kits/erp-app/App.jsx":"16cf1585c23a","ui_kits/erp-app/DataTable.jsx":"8d828302e7c4","ui_kits/erp-app/Icons.jsx":"ab04ca072331","ui_kits/erp-app/Modal.jsx":"d4eb6e1e6e32","ui_kits/erp-app/ModuleHero.jsx":"5ff70d65fac7","ui_kits/erp-app/Sidebar.jsx":"24b5d40413e6","ui_kits/erp-app/StatCard.jsx":"5b63c4a4e29a","ui_kits/erp-app/Toast.jsx":"e0412811cdaa","ui_kits/erp-app/Topbar.jsx":"a3de89df03ab","ui_kits/erp-app/data.js":"926c73390c71"},"inlinedExternals":[],"unexposedExports":[{"name":"toastAccent","sourcePath":"toast-system/toast-variants.ts"},{"name":"toastBar","sourcePath":"toast-system/toast-variants.ts"},{"name":"toastContainer","sourcePath":"toast-system/toast-variants.ts"},{"name":"toastIcon","sourcePath":"toast-system/toast-variants.ts"}]} */

(() => {

const __ds_ns = (window.OfferBerriesDesignSystem_cc94b3 = window.OfferBerriesDesignSystem_cc94b3 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// frontend/src/components/layouts/DashboardLayout.jsx
try { (() => {
// src/components/layout/DashboardLayout.jsx
// ============================================================
// Universal layout wrapper for all ERP module pages.
// Usage:
//   <DashboardLayout sidebar={<Sidebar ... />} title="My Page">
//     {children}
//   </DashboardLayout>
// ============================================================

const DashboardLayout = ({
  sidebar,
  children,
  className = ""
}) => /*#__PURE__*/React.createElement("div", {
  className: `flex min-h-screen bg-page ${className}`
}, sidebar && /*#__PURE__*/React.createElement("div", {
  className: "sticky top-0 h-screen flex-shrink-0"
}, sidebar), /*#__PURE__*/React.createElement("main", {
  className: "flex-1 overflow-y-auto erp-scroll"
}, /*#__PURE__*/React.createElement("div", {
  className: "p-6 max-w-screen-2xl mx-auto"
}, children)));
Object.assign(__ds_scope, { DashboardLayout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "frontend/src/components/layouts/DashboardLayout.jsx", error: String((e && e.message) || e) }); }

// frontend/src/components/layouts/Sidebar.jsx
try { (() => {
// src/components/layout/Sidebar.jsx
const {
  useState,
  useEffect
} = React;
/* ─── Module brand config ── */
const MODULE_CONFIG = {
  AdminDashboard: {
    label: "HR Module",
    gradient: "var(--hr-gradient)"
  },
  SalaryDashboard: {
    label: "Finance",
    gradient: "var(--fin-gradient)"
  },
  PermissionsManager: {
    label: "HR Module",
    gradient: "var(--hr-gradient)"
  },
  "Sellers Dashboard": {
    label: "Business Ops",
    gradient: "var(--ops-gradient)"
  },
  "Pending Account Statements": {
    label: "Business Ops",
    gradient: "var(--ops-gradient)"
  },
  "Paid Account Statements": {
    label: "Business Ops",
    gradient: "var(--ops-gradient)"
  },
  default: {
    label: "ERP Suite",
    gradient: "var(--hr-gradient)"
  }
};
const DEPT_COLORS = {
  Finance: "var(--fin-accent)",
  HR: "var(--hr-accent)",
  BusinessOperation: "var(--ops-accent)",
  IT: "#06B6D4",
  Compliance: "#F59E0B",
  All: "var(--text-muted)"
};

/* ─── Tooltip ── */
const Tooltip = ({
  text,
  children
}) => {
  const [show, setShow] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: "calc(100% + 10px)",
      top: "50%",
      transform: "translateY(-50%)",
      background: "#1A2236",
      border: "1px solid rgba(255,255,255,.1)",
      color: "var(--text-inverse)",
      fontSize: "var(--text-xs)",
      fontWeight: 500,
      padding: "6px 12px",
      borderRadius: "var(--radius-md)",
      whiteSpace: "nowrap",
      boxShadow: "var(--shadow-lg)",
      zIndex: "var(--z-tooltip)"
    }
  }, text));
};

/* ─── Org Tree Node ── */
const CompactTreeNode = ({
  node,
  level = 0,
  onNodeSelect,
  selectedId
}) => {
  const [expanded, setExpanded] = useState(level < 1);
  const hasChildren = node.children?.length > 0;
  const isSelected = selectedId === node._id;
  const color = DEPT_COLORS[node.departmentCode] || "var(--text-muted)";
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    onClick: () => onNodeSelect(node, !hasChildren),
    style: {
      display: "flex",
      alignItems: "center",
      padding: `6px ${8 + level * 12}px 6px 8px`,
      borderRadius: "var(--radius-sm)",
      cursor: "pointer",
      background: isSelected ? "rgba(99,102,241,0.14)" : "transparent",
      transition: "background var(--transition-fast)",
      marginBottom: 1,
      gap: "var(--space-2)"
    },
    onMouseEnter: e => {
      if (!isSelected) e.currentTarget.style.background = "rgba(255,255,255,.05)";
    },
    onMouseLeave: e => {
      if (!isSelected) e.currentTarget.style.background = "transparent";
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: e => {
      e.stopPropagation();
      if (hasChildren) setExpanded(!expanded);
    },
    style: {
      width: 16,
      height: 16,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "none",
      border: "none",
      cursor: hasChildren ? "pointer" : "default",
      color: "rgba(255,255,255,.3)",
      flexShrink: 0
    }
  }, hasChildren ? expanded ? /*#__PURE__*/React.createElement(ChevronDown, {
    size: 11
  }) : /*#__PURE__*/React.createElement(ChevronRight, {
    size: 11
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      color,
      flexShrink: 0
    }
  }, hasChildren ? /*#__PURE__*/React.createElement(Building2, {
    size: 12
  }) : /*#__PURE__*/React.createElement(Users, {
    size: 12
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      color: isSelected ? "var(--sidebar-text-active)" : "var(--sidebar-text)",
      fontWeight: isSelected ? 600 : 400,
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, node.name)), expanded && hasChildren && /*#__PURE__*/React.createElement("div", null, node.children.map(child => /*#__PURE__*/React.createElement(CompactTreeNode, {
    key: child._id,
    node: child,
    level: level + 1,
    onNodeSelect: onNodeSelect,
    selectedId: selectedId
  }))));
};

/* ─── Mini Org Tree ── */
const MiniHierarchyTree = ({
  onNodeSelect,
  isCollapsed
}) => {
  const [treeData, setTreeData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const [isExpanded, setIsExpanded] = useState(true);
  useEffect(() => {
    if (!isCollapsed) fetchTree();
  }, [isCollapsed]);
  const fetchTree = async () => {
    try {
      setLoading(true);
      const res = await api.get("/org-units");
      const data = await res.data;
      setTreeData(Array.isArray(data) ? data : data.data || [data]);
    } catch {/* silent */} finally {
      setLoading(false);
    }
  };
  if (isCollapsed) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderBottom: "1px solid var(--sidebar-border)"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setIsExpanded(!isExpanded),
    style: {
      width: "100%",
      padding: "10px 16px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "var(--sidebar-text)",
      fontSize: "var(--text-xs)",
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-2)"
    }
  }, /*#__PURE__*/React.createElement(Building2, {
    size: 13
  }), " Organization"), isExpanded ? /*#__PURE__*/React.createElement(ChevronDown, {
    size: 13
  }) : /*#__PURE__*/React.createElement(ChevronRight, {
    size: 13
  })), isExpanded && /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 240,
      overflowY: "auto",
      padding: "4px 8px 8px"
    },
    className: "erp-scroll"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      padding: "12px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 18,
      height: 18,
      borderRadius: "50%",
      border: "2px solid var(--hr-accent)",
      borderTopColor: "transparent",
      animation: "spin 0.8s linear infinite"
    }
  })) : treeData.map(node => /*#__PURE__*/React.createElement(CompactTreeNode, {
    key: node._id,
    node: node,
    onNodeSelect: (n, leaf) => {
      setSelectedId(n._id);
      onNodeSelect(n, leaf);
    },
    selectedId: selectedId
  }))));
};

/* ─── MAIN SIDEBAR ── */
const Sidebar = ({
  fetchEmployeesByNode,
  navItems = [],
  title
}) => {
  const [activeItem, setActiveItem] = useState(null);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const config = MODULE_CONFIG[title] || MODULE_CONFIG.default;
  const handleNav = item => {
    setActiveItem(item.name);
    if (item.path) window.location.href = item.path;else if (item.action) item.action();
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: isCollapsed ? "var(--sidebar-collapsed)" : "var(--sidebar-width)",
      flexShrink: 0,
      background: "var(--sidebar-bg)",
      borderRight: "1px solid var(--sidebar-border)",
      height: "100vh",
      position: "sticky",
      top: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      transition: "width var(--transition-slow)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "18px 14px 14px",
      borderBottom: "1px solid var(--sidebar-border)",
      display: "flex",
      alignItems: "center",
      justifyContent: isCollapsed ? "center" : "space-between",
      gap: "var(--space-2)",
      flexShrink: 0
    }
  }, !isCollapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-2)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: "var(--radius-md)",
      background: config.gradient,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Layers, {
    size: 15,
    color: "white"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: 700,
      color: "var(--text-inverse)",
      whiteSpace: "nowrap"
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "var(--sidebar-section)",
      fontWeight: 600,
      letterSpacing: "0.05em",
      textTransform: "uppercase"
    }
  }, config.label))), /*#__PURE__*/React.createElement("button", {
    onClick: () => setIsCollapsed(!isCollapsed),
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "var(--sidebar-text)",
      padding: "var(--space-1)",
      borderRadius: "var(--radius-sm)",
      display: "flex",
      alignItems: "center",
      flexShrink: 0,
      transition: "color var(--transition-fast), background var(--transition-fast)"
    },
    onMouseEnter: e => {
      e.currentTarget.style.background = "rgba(255,255,255,.07)";
      e.currentTarget.style.color = "var(--text-inverse)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = "none";
      e.currentTarget.style.color = "var(--sidebar-text)";
    }
  }, isCollapsed ? /*#__PURE__*/React.createElement(ChevronRight, {
    size: 17
  }) : /*#__PURE__*/React.createElement(ChevronLeft, {
    size: 17
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      overflowX: "hidden"
    },
    className: "erp-scroll"
  }, title === "AdminDashboard" && fetchEmployeesByNode && /*#__PURE__*/React.createElement(MiniHierarchyTree, {
    onNodeSelect: fetchEmployeesByNode,
    isCollapsed: isCollapsed
  }), title === "PermissionsManager" && !isCollapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      margin: "var(--space-2) var(--space-2)",
      padding: "var(--space-2) var(--space-3)",
      background: "rgba(245,158,11,.07)",
      borderRadius: "var(--radius-md)",
      border: "1px solid rgba(245,158,11,.15)",
      display: "flex",
      alignItems: "flex-start",
      gap: "var(--space-2)"
    }
  }, /*#__PURE__*/React.createElement(Info, {
    size: 13,
    color: "#FBBF24",
    style: {
      flexShrink: 0,
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "#FBBF24",
      lineHeight: 1.5,
      margin: 0
    }
  }, "Permission sync active. Changes propagate in ~5 min.")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-2)"
    }
  }, !isCollapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-2xs)",
      fontWeight: 700,
      color: "var(--sidebar-section)",
      textTransform: "uppercase",
      letterSpacing: "0.1em",
      padding: "6px var(--space-2) 4px"
    }
  }, "Menu"), navItems.map(item => {
    const isActive = activeItem === item.name;
    const btn = /*#__PURE__*/React.createElement("button", {
      key: item.name,
      onClick: () => handleNav(item),
      style: {
        display: "flex",
        alignItems: "center",
        gap: isCollapsed ? 0 : "var(--space-2)",
        justifyContent: isCollapsed ? "center" : "flex-start",
        width: "100%",
        padding: isCollapsed ? "var(--space-2)" : "9px var(--space-2)",
        borderRadius: "var(--radius-md)",
        border: isActive ? `none` : "none",
        borderLeft: isActive ? `2px solid var(--sidebar-active-bar)` : "2px solid transparent",
        cursor: "pointer",
        background: isActive ? "var(--sidebar-active-bg)" : "transparent",
        color: isActive ? "var(--sidebar-text-active)" : "var(--sidebar-text)",
        fontSize: "var(--text-sm)",
        fontWeight: isActive ? 600 : 500,
        textAlign: "left",
        marginBottom: 2,
        transition: "background var(--transition-fast), color var(--transition-fast)",
        overflow: "hidden",
        paddingLeft: isCollapsed ? undefined : isActive ? "calc(var(--space-2) - 2px)" : "var(--space-2)"
      },
      onMouseEnter: e => {
        if (!isActive) {
          e.currentTarget.style.background = "rgba(255,255,255,.05)";
          e.currentTarget.style.color = "var(--sidebar-text-hover)";
        }
      },
      onMouseLeave: e => {
        if (!isActive) {
          e.currentTarget.style.background = "transparent";
          e.currentTarget.style.color = "var(--sidebar-text)";
        }
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        flexShrink: 0,
        display: "flex",
        alignItems: "center"
      }
    }, item.icon), !isCollapsed && /*#__PURE__*/React.createElement("span", {
      style: {
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis"
      }
    }, item.name));
    return isCollapsed ? /*#__PURE__*/React.createElement(Tooltip, {
      key: item.name,
      text: item.name
    }, btn) : /*#__PURE__*/React.createElement("div", {
      key: item.name
    }, btn);
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-3) var(--space-4)",
      borderTop: "1px solid var(--sidebar-border)",
      display: "flex",
      alignItems: "center",
      justifyContent: isCollapsed ? "center" : "flex-start"
    }
  }, isCollapsed ? /*#__PURE__*/React.createElement(Tooltip, {
    text: "Enterprise Suite v2.0"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: "var(--sidebar-section)"
    }
  })) : /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "var(--sidebar-section)",
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.06em",
      margin: 0
    }
  }, "Enterprise Suite v2.0")));
};
Object.assign(__ds_scope, { Sidebar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "frontend/src/components/layouts/Sidebar.jsx", error: String((e && e.message) || e) }); }

// frontend/src/components/ui/index.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// src/components/ui/index.jsx
// ============================================================
// OfferBerries ERP — Core UI Components
// Button, Badge, Input, Card, Modal, Dropdown, Table, Avatar
// ============================================================
const {
  useState,
  useRef,
  useEffect
} = React;
// ─────────────────────────────────────────────────────────────
// BUTTON
// ─────────────────────────────────────────────────────────────
/**
 * @param {'primary'|'outline'|'ghost'|'danger'} variant
 * @param {'hr'|'fin'|'ops'} module  – controls gradient for 'primary'
 * @param {'sm'|'md'|'lg'} size
 */
const Button = ({
  children,
  variant = "primary",
  module = "hr",
  size = "md",
  loading = false,
  disabled = false,
  className = "",
  ...props
}) => {
  const gradients = {
    hr: "bg-hr-gradient",
    fin: "bg-fin-gradient",
    ops: "bg-ops-gradient"
  };
  const sizes = {
    sm: "px-3 py-1.5 text-caption",
    md: "px-4 py-2 text-body",
    lg: "px-5 py-2.5 text-h3"
  };
  const base = `
    inline-flex items-center justify-center gap-2
    font-medium rounded-md
    transition-all duration-150
    active:scale-97
    disabled:opacity-50 disabled:cursor-not-allowed
    select-none
  `;
  const variants = {
    primary: `${gradients[module]} text-white hover:opacity-88`,
    outline: `bg-transparent border-1.5 border-${module}-from text-${module}-text hover:bg-${module}-bg`,
    ghost: "bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100",
    danger: "bg-red-50 border border-red-200 text-red-700 hover:bg-red-100"
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    className: `${base} ${sizes[size]} ${variants[variant]} ${className}`,
    disabled: disabled || loading
  }, props), loading && /*#__PURE__*/React.createElement(Loader2, {
    size: 14,
    className: "animate-spin"
  }), children);
};

// ─────────────────────────────────────────────────────────────
// BADGE
// ─────────────────────────────────────────────────────────────
const BADGE_STYLES = {
  approved: "bg-green-50   text-green-700  border-green-200",
  pending: "bg-orange-50  text-orange-700 border-orange-200",
  rejected: "bg-red-50     text-red-700    border-red-200",
  draft: "bg-blue-50    text-blue-700   border-blue-200",
  suspended: "bg-purple-50  text-purple-700 border-purple-200",
  blocked: "bg-slate-900  text-slate-300  border-slate-700",
  terminated: "bg-red-50     text-red-800    border-red-300",
  paid: "bg-green-50   text-green-700  border-emerald-400",
  restored: "bg-teal-50    text-teal-700   border-teal-200",
  active: "bg-green-50   text-green-700  border-green-200",
  inactive: "bg-slate-50   text-slate-500  border-slate-200"
};
const STATUS_DOT = {
  approved: "bg-green-500",
  active: "bg-green-500",
  paid: "bg-emerald-500",
  pending: "bg-orange-400",
  rejected: "bg-red-500",
  terminated: "bg-red-700",
  suspended: "bg-purple-500",
  blocked: "bg-slate-400",
  draft: "bg-blue-500",
  restored: "bg-teal-500"
};
const Badge = ({
  children,
  status,
  className = ""
}) => {
  const key = (status || "draft").toLowerCase();
  const style = BADGE_STYLES[key] || BADGE_STYLES.draft;
  const dot = STATUS_DOT[key];
  return /*#__PURE__*/React.createElement("span", {
    className: `
        inline-flex items-center gap-1.5
        px-2 py-0.5 rounded-full text-2xs font-medium
        border
        ${style} ${className}
      `
  }, dot && /*#__PURE__*/React.createElement("span", {
    className: `w-1.5 h-1.5 rounded-full ${dot}`
  }), children);
};

// ─────────────────────────────────────────────────────────────
// INPUT
// ─────────────────────────────────────────────────────────────
const Input = ({
  label,
  error,
  hint,
  className = "",
  wrapperClassName = "",
  ...props
}) => /*#__PURE__*/React.createElement("div", {
  className: `flex flex-col gap-1.5 ${wrapperClassName}`
}, label && /*#__PURE__*/React.createElement("label", {
  className: "text-label text-slate-700 font-medium"
}, label), /*#__PURE__*/React.createElement("input", _extends({
  className: `
        w-full px-3 py-2.5 min-h-[40px]
        text-body text-slate-800
        bg-white border border-slate-200 rounded-md
        placeholder:text-slate-400
        transition-all duration-150
        focus:outline-none focus:border-indigo-500 focus:shadow-focus
        disabled:bg-slate-50 disabled:text-slate-400 disabled:cursor-not-allowed
        ${error ? "border-red-400 focus:shadow-focus-danger" : ""}
        ${className}
      `
}, props)), error && /*#__PURE__*/React.createElement("p", {
  className: "text-caption text-red-600"
}, error), hint && !error && /*#__PURE__*/React.createElement("p", {
  className: "text-caption text-slate-400"
}, hint));
const Select = ({
  label,
  error,
  children,
  className = "",
  wrapperClassName = "",
  ...props
}) => /*#__PURE__*/React.createElement("div", {
  className: `flex flex-col gap-1.5 ${wrapperClassName}`
}, label && /*#__PURE__*/React.createElement("label", {
  className: "text-label text-slate-700 font-medium"
}, label), /*#__PURE__*/React.createElement("select", _extends({
  className: `
        w-full px-3 py-2.5 min-h-[40px]
        text-body text-slate-800
        bg-white border border-slate-200 rounded-md
        transition-all duration-150
        focus:outline-none focus:border-indigo-500 focus:shadow-focus
        ${error ? "border-red-400" : ""}
        ${className}
      `
}, props), children), error && /*#__PURE__*/React.createElement("p", {
  className: "text-caption text-red-600"
}, error));
const Textarea = ({
  label,
  error,
  className = "",
  wrapperClassName = "",
  ...props
}) => /*#__PURE__*/React.createElement("div", {
  className: `flex flex-col gap-1.5 ${wrapperClassName}`
}, label && /*#__PURE__*/React.createElement("label", {
  className: "text-label text-slate-700 font-medium"
}, label), /*#__PURE__*/React.createElement("textarea", _extends({
  className: `
        w-full px-3 py-2.5
        text-body text-slate-800
        bg-white border border-slate-200 rounded-md
        placeholder:text-slate-400
        transition-all duration-150
        focus:outline-none focus:border-indigo-500 focus:shadow-focus
        resize-y min-h-[80px]
        ${error ? "border-red-400" : ""}
        ${className}
      `
}, props)), error && /*#__PURE__*/React.createElement("p", {
  className: "text-caption text-red-600"
}, error));

// ─────────────────────────────────────────────────────────────
// CARD
// ─────────────────────────────────────────────────────────────
const Card = ({
  children,
  className = "",
  hover = false,
  padding = "p-4",
  ...props
}) => /*#__PURE__*/React.createElement("div", _extends({
  className: `
      bg-canvas border border-slate-100 rounded-xl shadow-xs
      ${hover ? "hover:-translate-y-0.5 hover:shadow-md transition-all duration-150 cursor-pointer" : ""}
      ${padding} ${className}
    `
}, props), children);

/**
 * Module hero card with gradient background + decorative circles
 */
const ModuleCard = ({
  module = "hr",
  children,
  className = "",
  ...props
}) => {
  const gradients = {
    hr: "bg-hr-gradient",
    fin: "bg-fin-gradient",
    ops: "bg-ops-gradient"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `
        relative overflow-hidden rounded-xl text-white
        ${gradients[module]} shadow-md
        p-5 ${className}
      `
  }, props), /*#__PURE__*/React.createElement("div", {
    className: "absolute -top-8 -right-8 w-32 h-32 rounded-full bg-white opacity-5"
  }), /*#__PURE__*/React.createElement("div", {
    className: "absolute -bottom-6 -left-6 w-24 h-24 rounded-full bg-white opacity-5"
  }), /*#__PURE__*/React.createElement("div", {
    className: "relative z-10"
  }, children));
};

// ─────────────────────────────────────────────────────────────
// STAT CARD
// ─────────────────────────────────────────────────────────────
const StatCard = ({
  label,
  value,
  trend,
  trendLabel,
  icon,
  module = "hr",
  className = ""
}) => {
  const tints = {
    hr: "bg-indigo-50 border-indigo-100",
    fin: "bg-sky-50    border-sky-100",
    ops: "bg-orange-50 border-orange-100"
  };
  const textColors = {
    hr: "text-indigo-800",
    fin: "text-sky-800",
    ops: "text-orange-800"
  };
  const labelColors = {
    hr: "text-indigo-600",
    fin: "text-sky-600",
    ops: "text-orange-600"
  };
  const trendColor = trend === undefined ? "" : trend > 0 ? "text-green-600" : trend < 0 ? "text-red-500" : "text-slate-500";
  return /*#__PURE__*/React.createElement("div", {
    className: `
        rounded-xl border p-4 flex items-start justify-between gap-3
        ${tints[module]} ${className}
      `
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex-1 min-w-0"
  }, /*#__PURE__*/React.createElement("p", {
    className: `text-2xs uppercase tracking-wider mb-1 ${labelColors[module]}`
  }, label), /*#__PURE__*/React.createElement("p", {
    className: `text-display font-medium leading-none ${textColors[module]}`
  }, value), trend !== undefined && /*#__PURE__*/React.createElement("p", {
    className: `text-caption mt-1.5 ${trendColor}`
  }, trend > 0 ? "▲" : trend < 0 ? "▼" : "—", " ", trendLabel || `${Math.abs(trend)}%`)), icon && /*#__PURE__*/React.createElement("div", {
    className: `p-2 rounded-lg ${tints[module]} opacity-80`
  }, icon));
};

// ─────────────────────────────────────────────────────────────
// AVATAR
// ─────────────────────────────────────────────────────────────
const Avatar = ({
  src,
  name = "",
  size = "md",
  module = "hr",
  className = ""
}) => {
  const sizes = {
    sm: "w-8 h-8 text-xs",
    md: "w-11 h-11 text-sm",
    lg: "w-16 h-16 text-xl"
  };
  const gradients = {
    hr: "from-indigo-500 to-violet-600",
    fin: "from-sky-500 to-emerald-500",
    ops: "from-orange-500 to-amber-400"
  };
  const initials = name.split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase();
  return src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    className: `rounded-full object-cover ${sizes[size]} ${className}`
  }) : /*#__PURE__*/React.createElement("div", {
    className: `
        rounded-full flex items-center justify-center text-white font-medium
        bg-gradient-to-br ${gradients[module]}
        ${sizes[size]} ${className}
      `
  }, initials || "?");
};

// ─────────────────────────────────────────────────────────────
// MODAL
// ─────────────────────────────────────────────────────────────
const Modal = ({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  size = "md",
  className = ""
}) => {
  if (!open) return null;
  const sizes = {
    sm: "max-w-md",
    md: "max-w-2xl",
    lg: "max-w-4xl",
    xl: "max-w-6xl",
    full: "max-w-[95vw]"
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm",
    onClick: e => e.target === e.currentTarget && onClose?.()
  }, /*#__PURE__*/React.createElement("div", {
    className: `
          bg-canvas w-full ${sizes[size]} rounded-2xl shadow-lg
          flex flex-col max-h-[90vh]
          ${className}
        `
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-start justify-between p-6 border-b border-slate-100 flex-shrink-0"
  }, /*#__PURE__*/React.createElement("div", null, title && /*#__PURE__*/React.createElement("h2", {
    className: "text-h2 text-slate-900"
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    className: "text-caption text-slate-500 mt-0.5"
  }, subtitle)), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    className: "p-1.5 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-all ml-4"
  }, /*#__PURE__*/React.createElement(X, {
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "flex-1 overflow-y-auto erp-scroll p-6"
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    className: "flex justify-end gap-2 p-6 border-t border-slate-100 flex-shrink-0"
  }, footer)));
};

// ─────────────────────────────────────────────────────────────
// DROPDOWN MENU
// ─────────────────────────────────────────────────────────────
const Dropdown = ({
  trigger,
  items = [],
  align = "right"
}) => {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const handler = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    className: "relative inline-block"
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => setOpen(o => !o)
  }, trigger), open && /*#__PURE__*/React.createElement("div", {
    className: `
            absolute z-50 mt-1 w-48 bg-canvas rounded-lg border border-slate-100
            shadow-md py-1 overflow-hidden
            ${align === "right" ? "right-0" : "left-0"}
          `
  }, items.map((item, idx) => item.separator ? /*#__PURE__*/React.createElement("div", {
    key: idx,
    className: "my-1 border-t border-slate-100"
  }) : /*#__PURE__*/React.createElement("button", {
    key: idx,
    onClick: () => {
      item.onClick?.();
      setOpen(false);
    },
    className: `
                  w-full text-left px-4 py-2 text-caption
                  transition-colors duration-100
                  ${item.danger ? "text-red-600 hover:bg-red-50" : "text-slate-700 hover:bg-subtle"}
                  ${item.disabled ? "opacity-40 cursor-not-allowed" : ""}
                  flex items-center gap-2
                `,
    disabled: item.disabled
  }, item.icon && /*#__PURE__*/React.createElement("span", {
    className: "opacity-60"
  }, item.icon), item.label))));
};

// ─────────────────────────────────────────────────────────────
// TABLE
// ─────────────────────────────────────────────────────────────
const Table = ({
  columns = [],
  data = [],
  loading = false,
  emptyMessage = "No data found"
}) => /*#__PURE__*/React.createElement("div", {
  className: "w-full overflow-x-auto rounded-xl border border-slate-100 bg-canvas"
}, /*#__PURE__*/React.createElement("table", {
  className: "w-full text-left border-collapse"
}, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
  className: "bg-subtle border-b border-slate-100"
}, columns.map((col, i) => /*#__PURE__*/React.createElement("th", {
  key: i,
  className: "px-4 py-3 text-2xs uppercase tracking-wider text-slate-400 font-medium",
  style: {
    width: col.width
  }
}, col.header)))), /*#__PURE__*/React.createElement("tbody", null, loading ? /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
  colSpan: columns.length,
  className: "px-4 py-12 text-center"
}, /*#__PURE__*/React.createElement("div", {
  className: "flex justify-center"
}, /*#__PURE__*/React.createElement("div", {
  className: "animate-spin rounded-full h-8 w-8 border-2 border-indigo-500 border-t-transparent"
})))) : data.length === 0 ? /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
  colSpan: columns.length,
  className: "px-4 py-12 text-center text-caption text-slate-400 italic"
}, emptyMessage)) : data.map((row, ri) => /*#__PURE__*/React.createElement("tr", {
  key: ri,
  className: "border-b border-slate-50 hover:bg-subtle/60 transition-colors"
}, columns.map((col, ci) => /*#__PURE__*/React.createElement("td", {
  key: ci,
  className: "px-4 py-3 text-caption text-slate-700"
}, col.render ? col.render(row[col.key], row) : row[col.key] ?? "—")))))));

// ─────────────────────────────────────────────────────────────
// LOADER
// ─────────────────────────────────────────────────────────────
const Loader = ({
  fullPage = false
}) => /*#__PURE__*/React.createElement("div", {
  className: `flex justify-center items-center ${fullPage ? "min-h-screen" : "min-h-[60vh]"}`
}, /*#__PURE__*/React.createElement("div", {
  className: "animate-spin rounded-full h-10 w-10 border-2 border-indigo-500 border-t-transparent"
}));

// ─────────────────────────────────────────────────────────────
// SECTION HEADER
// ─────────────────────────────────────────────────────────────
const SectionHeader = ({
  title,
  subtitle,
  actions
}) => /*#__PURE__*/React.createElement("div", {
  className: "flex flex-wrap items-start justify-between gap-4 mb-6"
}, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
  className: "text-h1 text-slate-900"
}, title), subtitle && /*#__PURE__*/React.createElement("p", {
  className: "text-caption text-slate-500 mt-0.5"
}, subtitle)), actions && /*#__PURE__*/React.createElement("div", {
  className: "flex items-center gap-2"
}, actions));

// ─────────────────────────────────────────────────────────────
// DYNAMIC FIELD SECTION (allowances / deductions)
// ─────────────────────────────────────────────────────────────
const DynamicFieldSection = ({
  title,
  items = [],
  setItems,
  isEditing = true
}) => /*#__PURE__*/React.createElement("div", {
  className: "rounded-xl border border-slate-100 bg-subtle/40 p-4 mb-4"
}, /*#__PURE__*/React.createElement("div", {
  className: "flex items-center justify-between mb-3"
}, /*#__PURE__*/React.createElement("h3", {
  className: "text-h3 text-slate-800"
}, title), isEditing && /*#__PURE__*/React.createElement(Button, {
  size: "sm",
  variant: "outline",
  module: "hr",
  type: "button",
  onClick: () => setItems([...items, {
    name: "",
    type: "fixed",
    value: 0
  }])
}, "+ Add")), items.length === 0 && /*#__PURE__*/React.createElement("p", {
  className: "text-caption text-slate-400 italic"
}, "No ", title.toLowerCase(), " defined."), /*#__PURE__*/React.createElement("div", {
  className: "space-y-2"
}, items.map((item, idx) => /*#__PURE__*/React.createElement("div", {
  key: idx,
  className: "flex gap-2 items-center bg-canvas rounded-lg p-2 border border-slate-100"
}, isEditing ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Input, {
  className: "flex-1",
  placeholder: "Name",
  value: item.name,
  onChange: e => {
    const u = [...items];
    u[idx].name = e.target.value;
    setItems(u);
  }
}), /*#__PURE__*/React.createElement(Select, {
  className: "w-32",
  value: item.type,
  onChange: e => {
    const u = [...items];
    u[idx].type = e.target.value;
    setItems(u);
  }
}, /*#__PURE__*/React.createElement("option", {
  value: "fixed"
}, "Fixed"), /*#__PURE__*/React.createElement("option", {
  value: "percentage"
}, "%")), /*#__PURE__*/React.createElement(Input, {
  type: "number",
  className: "w-28",
  value: item.value,
  onChange: e => {
    const u = [...items];
    u[idx].value = Number(e.target.value);
    setItems(u);
  }
}), /*#__PURE__*/React.createElement("button", {
  type: "button",
  className: "p-1.5 rounded-md text-red-400 hover:text-red-600 hover:bg-red-50 transition-all",
  onClick: () => setItems(items.filter((_, i) => i !== idx))
}, /*#__PURE__*/React.createElement(X, {
  size: 14
}))) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
  className: "flex-1 text-body font-medium text-slate-800"
}, item.name), /*#__PURE__*/React.createElement("span", {
  className: "capitalize text-caption text-slate-500"
}, item.type), /*#__PURE__*/React.createElement("span", {
  className: "text-body font-medium text-slate-800 text-right w-28"
}, item.type === "percentage" ? `${item.value}%` : `PKR ${item.value}`))))));
try {
  void {
    Button,
    Badge,
    Input,
    Select,
    Textarea,
    Card,
    ModuleCard,
    StatCard,
    Avatar,
    Modal,
    Dropdown,
    Table,
    Loader,
    SectionHeader,
    DynamicFieldSection
  };
} catch {}
Object.assign(__ds_scope, { Button, Badge, Input, Select, Textarea, Card, ModuleCard, StatCard, Avatar, Modal, Dropdown, Table, Loader, SectionHeader, DynamicFieldSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "frontend/src/components/ui/index.jsx", error: String((e && e.message) || e) }); }

// toast-system/toast-variants.ts
try { (() => {
// toast-system/toast-variants.ts
// ---------------------------------------------------------------------------
// CVA variant system for the OfferBerries toast. Every visual axis (container
// surface, icon chip, accent rail) is a CVA recipe keyed off `ToastType`, so a
// new variant is one new key — never a new component.
// ---------------------------------------------------------------------------

/** Card container — the rounded-2xl glass surface. */
const toastContainer = cva(["group relative flex w-full items-start gap-3 overflow-hidden", "rounded-[18px] border p-[13px_14px]", "bg-canvas/95 supports-[backdrop-filter]:bg-canvas/80 backdrop-blur-sm backdrop-saturate-150", "border-border text-fg shadow-lg", "transition-[transform,opacity,filter] will-change-transform"], {
  variants: {
    type: {
      success: "",
      error: "",
      warning: "",
      info: "",
      loading: "",
      default: "",
      custom: "p-3"
    }
  },
  defaultVariants: {
    type: "default"
  }
});

/** Icon chip — soft tinted square behind the lucide glyph. */
const toastIcon = cva("flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-[9px]", {
  variants: {
    type: {
      success: "bg-success-bg text-success ring-4 ring-success/15",
      error: "bg-danger-bg text-danger ring-4 ring-danger/15",
      warning: "bg-warning-bg text-warning ring-4 ring-warning/15",
      info: "bg-info-bg text-info ring-4 ring-info/15",
      loading: "bg-info-bg text-indigo-500 ring-4 ring-indigo-500/15",
      default: "bg-page text-fg-secondary ring-4 ring-fg-muted/10",
      custom: "hidden"
    }
  },
  defaultVariants: {
    type: "default"
  }
});

/** Left accent rail — hidden for neutral/custom. */
const toastAccent = cva("absolute inset-y-0 left-0 w-[3px]", {
  variants: {
    type: {
      success: "bg-success opacity-90",
      error: "bg-danger opacity-90",
      warning: "bg-warning opacity-90",
      info: "bg-info opacity-90",
      loading: "bg-indigo-500 opacity-90",
      default: "opacity-0",
      custom: "opacity-0"
    }
  },
  defaultVariants: {
    type: "default"
  }
});

/** Timer / progress bar fill. */
const toastBar = cva("h-full rounded-r-full opacity-50", {
  variants: {
    type: {
      success: "bg-success",
      error: "bg-danger",
      warning: "bg-warning",
      info: "bg-info",
      loading: "bg-indigo-500",
      default: "bg-fg-muted",
      custom: "bg-fg-muted"
    }
  },
  defaultVariants: {
    type: "default"
  }
});

/** Map a variant to its lucide icon + whether it should spin. */
const ICON_FOR = {
  success: CheckCircle2,
  error: XCircle,
  warning: AlertTriangle,
  info: Info,
  loading: Loader2,
  default: Bell,
  custom: Sparkles
};
Object.assign(__ds_scope, { toastContainer, toastIcon, toastAccent, toastBar, ICON_FOR });
})(); } catch (e) { __ds_ns.__errors.push({ path: "toast-system/toast-variants.ts", error: String((e && e.message) || e) }); }

// ui_kits/erp-app/App.jsx
try { (() => {
// App.jsx — composes the full ERP shell
const {
  useState
} = React;
const moduleConfig = {
  workspace: {
    title: "Good evening, Hassan",
    subtitle: "5 items need your action today. Last sync 12 minutes ago.",
    stats: [{
      label: "Pending approvals",
      value: "5",
      mono: false
    }, {
      label: "Drafts",
      value: "2",
      mono: false
    }],
    kpis: [{
      label: "Inbox",
      value: "12",
      icon: "inbox",
      trend: "3 new today",
      dir: "up"
    }, {
      label: "Assigned tasks",
      value: "8",
      icon: "check",
      trend: "2 due this week",
      dir: "flat"
    }, {
      label: "Drafts saved",
      value: "2",
      icon: "file",
      trend: "Auto-saved 11 min",
      dir: "flat"
    }, {
      label: "Reports generated",
      value: "47",
      icon: "trend",
      trend: "May 2026",
      dir: "flat"
    }],
    tableTitle: "My recent activity",
    tableKind: "activity"
  },
  hr: {
    title: "Payroll for May 2026",
    subtitle: "1,284 active employees across 7 departments. Payroll closes 30 May at 17:00 PKT.",
    stats: [{
      label: "Active",
      value: "1,284"
    }, {
      label: "Leave today",
      value: "23"
    }, {
      label: "Open reqs",
      value: "8"
    }],
    kpis: [{
      label: "Active employees",
      value: "1,284",
      icon: "users",
      trend: "+4.2% vs last month",
      dir: "up"
    }, {
      label: "On leave",
      value: "23",
      icon: "calendar",
      trend: "8 unplanned",
      dir: "flat"
    }, {
      label: "Pending approvals",
      value: "12",
      icon: "check",
      trend: "Oldest: 3 days",
      dir: "flat"
    }, {
      label: "Open requisitions",
      value: "8",
      icon: "file",
      trend: "2 closing soon",
      dir: "down"
    }],
    tableTitle: "Employees · Payroll review",
    tableKind: "employees"
  },
  finance: {
    title: "Outstanding ledger · May 2026",
    subtitle: "PKR 84.2M processed in payroll. 37 account statements awaiting reconciliation.",
    stats: [{
      label: "Payroll",
      value: "PKR 84.2M",
      mono: true
    }, {
      label: "Receivable",
      value: "PKR 41.6M",
      mono: true
    }, {
      label: "Payable",
      value: "PKR 18.9M",
      mono: true
    }],
    kpis: [{
      label: "Payroll · May",
      value: "PKR 84.2M",
      icon: "wallet",
      trend: "Processed 28 May",
      dir: "flat"
    }, {
      label: "Receivable",
      value: "PKR 41.6M",
      icon: "trend",
      trend: "+12% vs Apr",
      dir: "up"
    }, {
      label: "Pending statements",
      value: "37",
      icon: "file",
      trend: "Oldest: 6 days",
      dir: "flat"
    }, {
      label: "Reconciled",
      value: "412",
      icon: "check",
      trend: "This month",
      dir: "up"
    }],
    tableTitle: "Account statements",
    tableKind: "statements"
  },
  ops: {
    title: "Marketplace operations",
    subtitle: "812 active sellers · 37 awaiting onboarding review. Disputes SLA at 94% this week.",
    stats: [{
      label: "Active sellers",
      value: "812"
    }, {
      label: "Pending review",
      value: "37"
    }, {
      label: "Disputes",
      value: "14"
    }],
    kpis: [{
      label: "Active sellers",
      value: "812",
      icon: "shop",
      trend: "+18 this week",
      dir: "up"
    }, {
      label: "Pending review",
      value: "37",
      icon: "alert",
      trend: "12 over SLA",
      dir: "down"
    }, {
      label: "GMV · May",
      value: "PKR 1.42B",
      icon: "trend",
      trend: "+8% vs Apr",
      dir: "up"
    }, {
      label: "Open disputes",
      value: "14",
      icon: "info",
      trend: "SLA 94%",
      dir: "flat"
    }],
    tableTitle: "Sellers · Onboarding queue",
    tableKind: "sellers"
  },
  governance: {
    title: "Compliance & audit",
    subtitle: "Q2 2026 audit cycle in progress. 4 policies pending board review.",
    stats: [{
      label: "Policies",
      value: "127"
    }, {
      label: "Open audits",
      value: "4"
    }, {
      label: "Incidents",
      value: "0"
    }],
    kpis: [{
      label: "Policies",
      value: "127",
      icon: "shield",
      trend: "4 pending board",
      dir: "flat"
    }, {
      label: "Open audits",
      value: "4",
      icon: "file",
      trend: "Q2 cycle",
      dir: "flat"
    }, {
      label: "Compliance score",
      value: "98%",
      icon: "check",
      trend: "+2% vs Q1",
      dir: "up"
    }, {
      label: "Incidents · 30d",
      value: "0",
      icon: "alert",
      trend: "Clean record",
      dir: "up"
    }],
    tableTitle: "Audit log · last 48 hours",
    tableKind: "audit"
  }
};
const App = () => {
  const [activeMod, setActiveMod] = useState("hr");
  const [collapsed, setCollapsed] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [toast, setToast] = useState(null);
  const module = window.OB_MODULES.find(m => m.id === activeMod);
  const cfg = moduleConfig[activeMod];

  // Build table based on the active module
  const tables = {
    employees: {
      columns: [{
        key: "name",
        label: "Employee",
        render: r => /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Avatar, {
          name: r.name,
          tint: r.tint
        }), r.name)
      }, {
        key: "id",
        label: "Code",
        mono: true,
        nowrap: true
      }, {
        key: "dept",
        label: "Department"
      }, {
        key: "status",
        label: "Status",
        render: r => /*#__PURE__*/React.createElement(Badge, {
          status: r.status
        })
      }, {
        key: "net",
        label: "Net salary",
        align: "right",
        mono: true,
        nowrap: true
      }],
      rows: window.OB_DATA.employees
    },
    sellers: {
      columns: [{
        key: "name",
        label: "Seller"
      }, {
        key: "id",
        label: "Code",
        mono: true,
        nowrap: true
      }, {
        key: "category",
        label: "Category"
      }, {
        key: "reg",
        label: "Registered",
        mono: true,
        nowrap: true
      }, {
        key: "status",
        label: "Status",
        render: r => /*#__PURE__*/React.createElement(Badge, {
          status: r.status
        })
      }, {
        key: "gmv",
        label: "GMV · May",
        align: "right",
        mono: true
      }],
      rows: window.OB_DATA.sellers
    },
    statements: {
      columns: [{
        key: "id",
        label: "Statement",
        mono: true,
        nowrap: true
      }, {
        key: "date",
        label: "Date",
        mono: true,
        nowrap: true
      }, {
        key: "buyer",
        label: "Buyer"
      }, {
        key: "seller",
        label: "Seller"
      }, {
        key: "amount",
        label: "Amount",
        align: "right",
        mono: true
      }, {
        key: "status",
        label: "Status",
        render: r => /*#__PURE__*/React.createElement(Badge, {
          status: r.status
        })
      }],
      rows: window.OB_DATA.statements
    },
    activity: {
      columns: [{
        key: "time",
        label: "Time",
        mono: true,
        nowrap: true
      }, {
        key: "event",
        label: "Event"
      }, {
        key: "actor",
        label: "Actor"
      }, {
        key: "status",
        label: "Status",
        render: r => /*#__PURE__*/React.createElement(Badge, {
          status: r.status
        })
      }],
      rows: [{
        time: "17:42",
        event: "Approved statement ST-2419",
        actor: "You",
        status: "approved"
      }, {
        time: "15:08",
        event: "Saved draft · Payroll May",
        actor: "You",
        status: "draft"
      }, {
        time: "12:31",
        event: "Rejected seller SLR-1044",
        actor: "You",
        status: "rejected"
      }, {
        time: "09:14",
        event: "Payroll batch closed",
        actor: "System",
        status: "paid"
      }]
    },
    audit: {
      columns: [{
        key: "time",
        label: "Time",
        mono: true,
        nowrap: true
      }, {
        key: "actor",
        label: "Actor"
      }, {
        key: "action",
        label: "Action"
      }, {
        key: "object",
        label: "Object",
        mono: true,
        nowrap: true
      }, {
        key: "result",
        label: "Result",
        render: r => /*#__PURE__*/React.createElement(Badge, {
          status: r.result
        })
      }],
      rows: [{
        time: "28 May · 17:42",
        actor: "Hassan Mahmood",
        action: "Approved payment",
        object: "ST-2419",
        result: "approved"
      }, {
        time: "28 May · 16:10",
        actor: "System",
        action: "Policy sync",
        object: "POL-118",
        result: "paid"
      }, {
        time: "28 May · 12:31",
        actor: "Nimra Khan",
        action: "Rejected onboarding",
        object: "SLR-1044",
        result: "rejected"
      }, {
        time: "28 May · 09:14",
        actor: "Asad Rauf",
        action: "Closed audit",
        object: "AUD-Q2-03",
        result: "approved"
      }, {
        time: "27 May · 22:08",
        actor: "System",
        action: "Suspended user",
        object: "EMP-04222",
        result: "suspended"
      }]
    }
  };
  const tbl = tables[cfg.tableKind];
  const fireToast = (kind, title, body) => {
    setToast({
      kind,
      title,
      body
    });
    setTimeout(() => setToast(null), 4200);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      minHeight: "100vh",
      background: "var(--bg-page)"
    }
  }, /*#__PURE__*/React.createElement(Sidebar, {
    activeId: activeMod,
    onChange: setActiveMod,
    collapsed: collapsed,
    onToggle: () => setCollapsed(c => !c)
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement(Topbar, {
    module: module.name,
    breadcrumb: cfg.title.split(" · ")[0],
    onNewClick: () => setModalOpen(true)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1400,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement(ModuleHero, {
    module: module,
    title: cfg.title,
    subtitle: cfg.subtitle,
    stats: cfg.stats
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 14,
      marginBottom: 24
    }
  }, cfg.kpis.map((k, i) => /*#__PURE__*/React.createElement(StatCard, {
    key: i,
    label: k.label,
    value: k.value,
    icon: k.icon,
    gradient: module.gradient,
    trend: k.trend,
    trendDir: k.dir
  }))), /*#__PURE__*/React.createElement(DataTable, {
    title: cfg.tableTitle,
    columns: tbl.columns,
    rows: tbl.rows,
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", null, "Showing 1\u2013", tbl.rows.length, " of ", tbl.rows.length), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 6,
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "erp-btn erp-btn-ghost erp-btn-sm",
      disabled: true
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "chevL",
      size: 11
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-mono)"
      }
    }, "1 / 1"), /*#__PURE__*/React.createElement("button", {
      className: "erp-btn erp-btn-ghost erp-btn-sm",
      disabled: true
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "chevR",
      size: 11
    }))))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "2fr 1fr",
      gap: 14,
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "erp-card",
    style: {
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "erp-section-header",
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "erp-section-title"
  }, "Activity timeline"), /*#__PURE__*/React.createElement("span", {
    className: "erp-section-action"
  }, "View all")), [{
    t: "17:42",
    a: "Hassan Mahmood",
    v: "Approved payment ST-2419",
    k: "approved"
  }, {
    t: "15:08",
    a: "You",
    v: "Saved draft · Payroll May",
    k: "draft"
  }, {
    t: "12:31",
    a: "Nimra Khan",
    v: "Rejected seller SLR-1044",
    k: "rejected"
  }, {
    t: "09:14",
    a: "System",
    v: "Payroll batch closed",
    k: "paid"
  }].map((e, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      padding: "10px 0",
      borderBottom: i < 3 ? "1px solid var(--border-subtle)" : "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      color: "var(--text-muted)",
      width: 48,
      flexShrink: 0
    }
  }, e.t), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      fontSize: 13,
      color: "var(--text-primary)"
    }
  }, e.v), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text-secondary)",
      width: 130
    }
  }, e.a), /*#__PURE__*/React.createElement(Badge, {
    status: e.k
  })))), /*#__PURE__*/React.createElement("div", {
    className: "erp-card",
    style: {
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "erp-section-header",
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "erp-section-title"
  }, "Quick actions")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "erp-btn erp-btn-outline",
    style: {
      justifyContent: "flex-start",
      padding: "10px 14px"
    },
    onClick: () => fireToast("success", "Statement #ST-2419 paid", "PKR 84,500 transferred")
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 14
  }), " Approve next pending"), /*#__PURE__*/React.createElement("button", {
    className: "erp-btn erp-btn-ghost",
    style: {
      justifyContent: "flex-start",
      padding: "10px 14px"
    },
    onClick: () => fireToast("info", "Export queued", "CSV will be ready in ~30s")
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "download",
    size: 14
  }), " Export this view"), /*#__PURE__*/React.createElement("button", {
    className: "erp-btn erp-btn-ghost",
    style: {
      justifyContent: "flex-start",
      padding: "10px 14px"
    },
    onClick: () => fireToast("warning", "3 sellers awaiting review", "Oldest submission: 4 days ago")
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "alert",
    size: 14
  }), " Check SLA breaches"), /*#__PURE__*/React.createElement("button", {
    className: "erp-btn erp-btn-ghost",
    style: {
      justifyContent: "flex-start",
      padding: "10px 14px"
    },
    onClick: () => setModalOpen(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 14
  }), " New record"))))))), /*#__PURE__*/React.createElement(Modal, {
    open: modalOpen,
    onClose: () => setModalOpen(false),
    title: "Create new record",
    subtitle: "Choose a type and fill in the basics. You can save as draft.",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("button", {
      className: "erp-btn erp-btn-ghost",
      onClick: () => setModalOpen(false)
    }, "Cancel"), /*#__PURE__*/React.createElement("button", {
      className: "erp-btn erp-btn-ghost",
      onClick: () => {
        setModalOpen(false);
        fireToast("info", "Draft saved", "Auto-saved to your workspace");
      }
    }, "Save draft"), /*#__PURE__*/React.createElement("button", {
      className: "erp-btn erp-btn-primary",
      onClick: () => {
        setModalOpen(false);
        fireToast("success", "Record created", "Now visible in the queue");
      }
    }, "Create record"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(FormRow, {
    label: "Record type",
    required: true
  }, /*#__PURE__*/React.createElement("select", {
    className: "erp-input"
  }, /*#__PURE__*/React.createElement("option", null, "Employee"), /*#__PURE__*/React.createElement("option", null, "Seller"), /*#__PURE__*/React.createElement("option", null, "Statement"), /*#__PURE__*/React.createElement("option", null, "Leave request"))), /*#__PURE__*/React.createElement(FormRow, {
    label: "Department",
    required: true
  }, /*#__PURE__*/React.createElement("select", {
    className: "erp-input"
  }, /*#__PURE__*/React.createElement("option", null, "HR"), /*#__PURE__*/React.createElement("option", null, "Finance"), /*#__PURE__*/React.createElement("option", null, "Business Ops"), /*#__PURE__*/React.createElement("option", null, "Compliance"))), /*#__PURE__*/React.createElement(FormRow, {
    label: "Full name",
    required: true
  }, /*#__PURE__*/React.createElement("input", {
    className: "erp-input",
    placeholder: "e.g. Asad Rauf"
  })), /*#__PURE__*/React.createElement(FormRow, {
    label: "CNIC",
    required: true,
    hint: "13 digits, format auto-applied"
  }, /*#__PURE__*/React.createElement("input", {
    className: "erp-input",
    placeholder: "42101-XXXXXXX-X"
  })), /*#__PURE__*/React.createElement(FormRow, {
    label: "Joining date"
  }, /*#__PURE__*/React.createElement("input", {
    className: "erp-input",
    type: "date",
    defaultValue: "2026-05-28"
  })), /*#__PURE__*/React.createElement(FormRow, {
    label: "Reporting to"
  }, /*#__PURE__*/React.createElement("input", {
    className: "erp-input",
    placeholder: "Search employee\u2026"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1"
    }
  }, /*#__PURE__*/React.createElement(FormRow, {
    label: "Notes"
  }, /*#__PURE__*/React.createElement("textarea", {
    className: "erp-input",
    rows: "3",
    placeholder: "Internal notes (visible to HR only)\u2026"
  }))))), /*#__PURE__*/React.createElement(Toast, {
    toast: toast,
    onDismiss: () => setToast(null)
  }));
};
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/erp-app/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/erp-app/DataTable.jsx
try { (() => {
// DataTable.jsx
const DataTable = ({
  title,
  columns,
  rows,
  action,
  footer
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    background: "var(--bg-canvas)",
    border: "1px solid var(--border-default)",
    borderRadius: "var(--radius-lg)",
    overflow: "hidden",
    boxShadow: "var(--shadow-xs)"
  }
}, (title || action) && /*#__PURE__*/React.createElement("div", {
  style: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "14px 18px",
    borderBottom: "1px solid var(--border-subtle)"
  }
}, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
  style: {
    fontSize: 15,
    fontWeight: 500,
    color: "var(--text-primary)"
  }
}, title)), /*#__PURE__*/React.createElement("div", {
  style: {
    display: "flex",
    gap: 8
  }
}, /*#__PURE__*/React.createElement("button", {
  className: "erp-btn erp-btn-ghost erp-btn-sm"
}, /*#__PURE__*/React.createElement(Icon, {
  name: "filter",
  size: 12
}), " Filter"), /*#__PURE__*/React.createElement("button", {
  className: "erp-btn erp-btn-ghost erp-btn-sm"
}, /*#__PURE__*/React.createElement(Icon, {
  name: "download",
  size: 12
}), " Export"), action)), /*#__PURE__*/React.createElement("div", {
  style: {
    overflowX: "auto"
  }
}, /*#__PURE__*/React.createElement("table", {
  className: "erp-table"
}, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
  key: c.key,
  style: {
    textAlign: c.align || "left"
  }
}, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
  key: i
}, columns.map(c => /*#__PURE__*/React.createElement("td", {
  key: c.key,
  style: {
    textAlign: c.align || "left",
    fontFamily: c.mono ? "var(--font-mono)" : undefined,
    color: c.mono ? "var(--text-secondary)" : undefined,
    whiteSpace: c.nowrap ? "nowrap" : undefined
  }
}, c.render ? c.render(r) : r[c.key]))))))), footer && /*#__PURE__*/React.createElement("div", {
  style: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px 18px",
    borderTop: "1px solid var(--border-subtle)",
    fontSize: 12,
    color: "var(--text-muted)"
  }
}, footer));
window.DataTable = DataTable;

// Badge helper
const Badge = ({
  status
}) => /*#__PURE__*/React.createElement("span", {
  className: `erp-badge erp-badge-${status}`
}, status[0].toUpperCase() + status.slice(1));
window.Badge = Badge;

// Avatar helper
const Avatar = ({
  name,
  tint = ["#EEF2FF", "#3730A3"],
  initials,
  size = 26
}) => /*#__PURE__*/React.createElement("span", {
  style: {
    width: size,
    height: size,
    borderRadius: "50%",
    background: tint[0],
    color: tint[1],
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: Math.round(size * 0.4),
    fontWeight: 600,
    flexShrink: 0,
    marginRight: 10,
    verticalAlign: "middle"
  }
}, initials || name?.split(" ").map(s => s[0]).slice(0, 2).join(""));
window.Avatar = Avatar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/erp-app/DataTable.jsx", error: String((e && e.message) || e) }); }

// ui_kits/erp-app/Icons.jsx
try { (() => {
// Icons.jsx — lucide-style stroked icons, sized 1em
const Icon = ({
  name,
  size = 16,
  color = "currentColor",
  style
}) => {
  const props = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style
  };
  const P = {
    grid: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("rect", {
      x: "3",
      y: "3",
      width: "7",
      height: "9"
    }), /*#__PURE__*/React.createElement("rect", {
      x: "14",
      y: "3",
      width: "7",
      height: "5"
    }), /*#__PURE__*/React.createElement("rect", {
      x: "14",
      y: "12",
      width: "7",
      height: "9"
    }), /*#__PURE__*/React.createElement("rect", {
      x: "3",
      y: "16",
      width: "7",
      height: "5"
    })),
    users: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "9",
      cy: "7",
      r: "4"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M23 21v-2a4 4 0 0 0-3-3.87"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M16 3.13a4 4 0 0 1 0 7.75"
    })),
    wallet: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M21 12V7H5a2 2 0 0 1 0-4h14v4"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M3 5v14a2 2 0 0 0 2 2h16v-5"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M18 12a2 2 0 0 0 0 4h4v-4z"
    })),
    shop: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "3",
      y1: "6",
      x2: "21",
      y2: "6"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M16 10a4 4 0 0 1-8 0"
    })),
    shield: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"
    })),
    search: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("circle", {
      cx: "11",
      cy: "11",
      r: "8"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "21",
      y1: "21",
      x2: "16.65",
      y2: "16.65"
    })),
    bell: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M10.3 21a1.94 1.94 0 0 0 3.4 0"
    })),
    plus: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("line", {
      x1: "12",
      y1: "5",
      x2: "12",
      y2: "19"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "5",
      y1: "12",
      x2: "19",
      y2: "12"
    })),
    chevD: /*#__PURE__*/React.createElement("polyline", {
      points: "6 9 12 15 18 9"
    }),
    chevR: /*#__PURE__*/React.createElement("polyline", {
      points: "9 6 15 12 9 18"
    }),
    chevL: /*#__PURE__*/React.createElement("polyline", {
      points: "15 18 9 12 15 6"
    }),
    x: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("line", {
      x1: "18",
      y1: "6",
      x2: "6",
      y2: "18"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "6",
      y1: "6",
      x2: "18",
      y2: "18"
    })),
    check: /*#__PURE__*/React.createElement("polyline", {
      points: "20 6 9 17 4 12"
    }),
    alert: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "12",
      y1: "9",
      x2: "12",
      y2: "13"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "12",
      y1: "17",
      x2: "12.01",
      y2: "17"
    })),
    info: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "10"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "12",
      y1: "16",
      x2: "12",
      y2: "12"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "12",
      y1: "8",
      x2: "12.01",
      y2: "8"
    })),
    filter: /*#__PURE__*/React.createElement("polygon", {
      points: "22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"
    }),
    download: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
    }), /*#__PURE__*/React.createElement("polyline", {
      points: "7 10 12 15 17 10"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "12",
      y1: "15",
      x2: "12",
      y2: "3"
    })),
    more: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "5",
      r: "1"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "1"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "19",
      r: "1"
    })),
    sun: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "4"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"
    })),
    layers: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("polygon", {
      points: "12 2 2 7 12 12 22 7 12 2"
    }), /*#__PURE__*/React.createElement("polyline", {
      points: "2 17 12 22 22 17"
    }), /*#__PURE__*/React.createElement("polyline", {
      points: "2 12 12 17 22 12"
    })),
    inbox: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("polyline", {
      points: "22 12 16 12 14 15 10 15 8 12 2 12"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"
    })),
    file: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
      d: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"
    }), /*#__PURE__*/React.createElement("polyline", {
      points: "14 2 14 8 20 8"
    })),
    trend: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("polyline", {
      points: "22 7 13.5 15.5 8.5 10.5 2 17"
    }), /*#__PURE__*/React.createElement("polyline", {
      points: "16 7 22 7 22 13"
    })),
    calendar: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("rect", {
      x: "3",
      y: "4",
      width: "18",
      height: "18",
      rx: "2",
      ry: "2"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "16",
      y1: "2",
      x2: "16",
      y2: "6"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "8",
      y1: "2",
      x2: "8",
      y2: "6"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "3",
      y1: "10",
      x2: "21",
      y2: "10"
    })),
    settings: /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "3"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
    }))
  };
  return /*#__PURE__*/React.createElement("svg", props, P[name] || null);
};
window.Icon = Icon;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/erp-app/Icons.jsx", error: String((e && e.message) || e) }); }

// ui_kits/erp-app/Modal.jsx
try { (() => {
// Modal.jsx
const Modal = ({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer
}) => {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "erp-modal-overlay",
    onClick: onClose,
    style: {
      animation: "erp-fade-in 200ms ease-out both"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "erp-modal erp-modal-lg",
    onClick: e => e.stopPropagation(),
    style: {
      padding: 0,
      animation: "erp-scale-in 250ms cubic-bezier(0.34, 1.56, 0.64, 1) both"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      padding: "22px 24px 14px",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 500,
      color: "var(--text-primary)"
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text-secondary)",
      marginTop: 4
    }
  }, subtitle)), /*#__PURE__*/React.createElement("button", {
    className: "erp-btn erp-btn-icon",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 15
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "20px 24px"
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 10,
      padding: "14px 24px",
      borderTop: "1px solid var(--border-subtle)",
      background: "var(--bg-page)"
    }
  }, footer)));
};
window.Modal = Modal;

// FormRow helper
const FormRow = ({
  label,
  required,
  hint,
  error,
  children
}) => /*#__PURE__*/React.createElement("div", {
  className: "erp-field",
  style: {
    marginBottom: 14
  }
}, /*#__PURE__*/React.createElement("label", {
  className: "erp-field-label"
}, label, required && /*#__PURE__*/React.createElement("span", {
  className: "erp-required"
}, "*")), children, hint && !error && /*#__PURE__*/React.createElement("span", {
  className: "erp-field-hint"
}, hint), error && /*#__PURE__*/React.createElement("span", {
  className: "erp-field-error"
}, error));
window.FormRow = FormRow;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/erp-app/Modal.jsx", error: String((e && e.message) || e) }); }

// ui_kits/erp-app/ModuleHero.jsx
try { (() => {
// ModuleHero.jsx — gradient strip + title + summary
const ModuleHero = ({
  module,
  title,
  subtitle,
  stats
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    background: module.gradient,
    borderRadius: "var(--radius-xl)",
    padding: "22px 26px",
    color: "white",
    position: "relative",
    overflow: "hidden",
    marginBottom: 20
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    position: "absolute",
    top: -30,
    right: -30,
    width: 140,
    height: 140,
    borderRadius: "50%",
    background: "rgba(255,255,255,.08)",
    pointerEvents: "none"
  }
}), /*#__PURE__*/React.createElement("div", {
  style: {
    position: "absolute",
    bottom: -20,
    left: -20,
    width: 70,
    height: 70,
    borderRadius: "50%",
    background: "rgba(255,255,255,.05)",
    pointerEvents: "none"
  }
}), /*#__PURE__*/React.createElement("div", {
  style: {
    position: "relative",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-end",
    gap: 24
  }
}, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
  style: {
    fontSize: 11,
    fontWeight: 600,
    letterSpacing: ".08em",
    textTransform: "uppercase",
    opacity: .85
  }
}, module.name), /*#__PURE__*/React.createElement("div", {
  style: {
    fontSize: 28,
    fontWeight: 500,
    marginTop: 4,
    letterSpacing: "-0.01em"
  }
}, title), /*#__PURE__*/React.createElement("div", {
  style: {
    fontSize: 13,
    marginTop: 6,
    opacity: .85,
    maxWidth: 560
  }
}, subtitle)), stats && /*#__PURE__*/React.createElement("div", {
  style: {
    display: "flex",
    gap: 28
  }
}, stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
  key: i
}, /*#__PURE__*/React.createElement("div", {
  style: {
    fontSize: 11,
    fontWeight: 600,
    letterSpacing: ".06em",
    textTransform: "uppercase",
    opacity: .8
  }
}, s.label), /*#__PURE__*/React.createElement("div", {
  style: {
    fontSize: 22,
    fontWeight: 500,
    marginTop: 2,
    fontFamily: s.mono ? "var(--font-mono)" : "inherit"
  }
}, s.value))))));
window.ModuleHero = ModuleHero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/erp-app/ModuleHero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/erp-app/Sidebar.jsx
try { (() => {
// Sidebar.jsx
const Sidebar = ({
  activeId,
  onChange,
  collapsed,
  onToggle
}) => {
  const modules = window.OB_MODULES;
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: collapsed ? 56 : 228,
      flexShrink: 0,
      background: "var(--sidebar-bg)",
      borderRight: "1px solid var(--sidebar-border)",
      height: "100vh",
      position: "sticky",
      top: 0,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      transition: "width var(--transition-slow)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: collapsed ? "16px 8px" : "18px 14px 14px",
      borderBottom: "1px solid var(--sidebar-border)",
      display: "flex",
      alignItems: "center",
      justifyContent: collapsed ? "center" : "space-between",
      gap: 10,
      flexShrink: 0
    }
  }, !collapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: "var(--radius-md)",
      background: "var(--hr-gradient)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "layers",
    size: 15,
    color: "white"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: "var(--text-inverse)",
      letterSpacing: "-0.01em"
    }
  }, "OfferBerries"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: "var(--sidebar-section)",
      fontWeight: 600,
      letterSpacing: ".06em",
      textTransform: "uppercase"
    }
  }, "ERP Suite"))), collapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: "var(--radius-md)",
      background: "var(--hr-gradient)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "layers",
    size: 15,
    color: "white"
  })), !collapsed && /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "var(--sidebar-text)",
      padding: 4,
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevL",
    size: 16
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: 8
    }
  }, !collapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      color: "var(--sidebar-section)",
      textTransform: "uppercase",
      letterSpacing: ".1em",
      padding: "8px 8px 4px"
    }
  }, "Menu"), modules.map(m => {
    const active = m.id === activeId;
    return /*#__PURE__*/React.createElement("button", {
      key: m.id,
      onClick: () => onChange(m.id),
      title: collapsed ? m.name : undefined,
      style: {
        display: "flex",
        alignItems: "center",
        gap: collapsed ? 0 : 10,
        justifyContent: collapsed ? "center" : "flex-start",
        width: "100%",
        padding: collapsed ? "10px 0" : "9px 10px",
        borderRadius: "var(--radius-md)",
        border: "none",
        borderLeft: active ? "2px solid var(--sidebar-active-bar)" : "2px solid transparent",
        paddingLeft: collapsed ? 0 : active ? 8 : 10,
        cursor: "pointer",
        background: active ? "var(--sidebar-active-bg)" : "transparent",
        color: active ? "var(--sidebar-text-active)" : "var(--sidebar-text)",
        fontSize: 13,
        fontWeight: active ? 600 : 500,
        textAlign: "left",
        marginBottom: 2,
        transition: "all var(--transition-fast)"
      },
      onMouseEnter: e => {
        if (!active) {
          e.currentTarget.style.background = "rgba(255,255,255,.05)";
          e.currentTarget.style.color = "var(--sidebar-text-hover)";
        }
      },
      onMouseLeave: e => {
        if (!active) {
          e.currentTarget.style.background = "transparent";
          e.currentTarget.style.color = "var(--sidebar-text)";
        }
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: m.icon,
      size: 15
    }), !collapsed && /*#__PURE__*/React.createElement("span", {
      style: {
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis"
      }
    }, m.name));
  }), !collapsed && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      color: "var(--sidebar-section)",
      textTransform: "uppercase",
      letterSpacing: ".1em",
      padding: "16px 8px 4px"
    }
  }, "Quick links"), [{
    name: "Drafts",
    icon: "file"
  }, {
    name: "Approvals",
    icon: "check"
  }, {
    name: "Reports",
    icon: "trend"
  }, {
    name: "Calendar",
    icon: "calendar"
  }].map(q => /*#__PURE__*/React.createElement("div", {
    key: q.name,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "7px 10px",
      margin: "1px 0",
      borderRadius: "var(--radius-md)",
      color: "var(--sidebar-text)",
      fontSize: 12,
      fontWeight: 500,
      cursor: "pointer"
    },
    onMouseEnter: e => {
      e.currentTarget.style.background = "rgba(255,255,255,.04)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = "transparent";
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: q.icon,
    size: 13
  }), q.name)))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: collapsed ? "12px 8px" : "12px 14px",
      borderTop: "1px solid var(--sidebar-border)",
      display: "flex",
      alignItems: "center",
      justifyContent: collapsed ? "center" : "space-between"
    }
  }, collapsed ? /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "var(--sidebar-text)",
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevR",
    size: 16
  })) : /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 10,
      color: "var(--sidebar-section)",
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: ".06em",
      margin: 0
    }
  }, "Enterprise v2.0")));
};
window.Sidebar = Sidebar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/erp-app/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/erp-app/StatCard.jsx
try { (() => {
// StatCard.jsx
const StatCard = ({
  label,
  value,
  trend,
  trendDir,
  icon,
  gradient
}) => /*#__PURE__*/React.createElement("div", {
  className: "erp-stat-card",
  style: {
    padding: 18
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: 10
  }
}, /*#__PURE__*/React.createElement("div", {
  className: "erp-stat-label",
  style: {
    fontSize: 11,
    letterSpacing: ".07em",
    textTransform: "uppercase"
  }
}, label), /*#__PURE__*/React.createElement("div", {
  style: {
    width: 36,
    height: 36,
    borderRadius: "var(--radius-md)",
    background: gradient,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "white",
    flexShrink: 0
  }
}, /*#__PURE__*/React.createElement(Icon, {
  name: icon,
  size: 17
}))), /*#__PURE__*/React.createElement("div", {
  className: "erp-stat-value",
  style: {
    fontSize: 28,
    letterSpacing: "-0.01em"
  }
}, value), trend && /*#__PURE__*/React.createElement("div", {
  className: `erp-stat-trend erp-stat-trend-${trendDir || "flat"}`,
  style: {
    fontSize: 11
  }
}, trendDir === "up" ? "▲" : trendDir === "down" ? "▼" : "—", " ", trend));
window.StatCard = StatCard;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/erp-app/StatCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/erp-app/Toast.jsx
try { (() => {
// Toast.jsx
const Toast = ({
  toast,
  onDismiss
}) => {
  if (!toast) return null;
  const iconMap = {
    success: "check",
    warning: "alert",
    danger: "x",
    info: "info"
  };
  const colorMap = {
    success: "var(--success)",
    warning: "var(--warning)",
    danger: "var(--danger)",
    info: "var(--info)"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      bottom: 24,
      right: 24,
      zIndex: "var(--z-toast)",
      animation: "erp-slide-up 250ms cubic-bezier(0.4, 0, 0.2, 1) both"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: `erp-toast erp-toast-${toast.kind}`
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 28,
      borderRadius: "50%",
      background: `${colorMap[toast.kind]}1A`,
      color: colorMap[toast.kind],
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: iconMap[toast.kind],
    size: 14
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 500,
      color: "var(--text-primary)",
      fontSize: 13
    }
  }, toast.title), toast.body && /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--text-secondary)",
      fontSize: 12,
      marginTop: 2
    }
  }, toast.body)), /*#__PURE__*/React.createElement("button", {
    onClick: onDismiss,
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "var(--text-muted)",
      padding: 0,
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 13
  }))));
};
window.Toast = Toast;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/erp-app/Toast.jsx", error: String((e && e.message) || e) }); }

// ui_kits/erp-app/Topbar.jsx
try { (() => {
// Topbar.jsx
const Topbar = ({
  module,
  breadcrumb,
  onNewClick
}) => {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: "var(--topbar-height)",
      background: "var(--topbar-bg)",
      borderBottom: "1px solid var(--topbar-border)",
      display: "flex",
      alignItems: "center",
      padding: "0 24px",
      gap: 20,
      position: "sticky",
      top: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      fontSize: 13,
      color: "var(--text-secondary)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-muted)"
    }
  }, module), /*#__PURE__*/React.createElement(Icon, {
    name: "chevR",
    size: 12,
    color: "var(--text-muted)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-primary)",
      fontWeight: 500
    }
  }, breadcrumb)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      maxWidth: 480,
      marginLeft: "auto",
      display: "flex",
      alignItems: "center",
      gap: 8,
      background: "var(--bg-page)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      padding: "7px 12px"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 14,
    color: "var(--text-muted)"
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search employees, sellers, statements\u2026",
    style: {
      border: "none",
      background: "transparent",
      outline: "none",
      flex: 1,
      fontSize: 13,
      fontFamily: "inherit",
      color: "var(--text-primary)"
    }
  }), /*#__PURE__*/React.createElement("kbd", {
    style: {
      fontSize: 10,
      fontFamily: "var(--font-mono)",
      color: "var(--text-muted)",
      background: "var(--bg-canvas)",
      border: "1px solid var(--border-default)",
      borderRadius: 4,
      padding: "1px 6px"
    }
  }, "\u2318K")), /*#__PURE__*/React.createElement("button", {
    className: "erp-btn erp-btn-icon",
    "aria-label": "notifications",
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 15
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 6,
      right: 7,
      width: 7,
      height: 7,
      borderRadius: "50%",
      background: "var(--danger)",
      border: "1.5px solid var(--bg-canvas)"
    }
  })), /*#__PURE__*/React.createElement("button", {
    className: "erp-btn erp-btn-icon",
    "aria-label": "settings"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "settings",
    size: 15
  })), /*#__PURE__*/React.createElement("button", {
    className: "erp-btn erp-btn-primary",
    onClick: onNewClick
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 14
  }), " New record"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      paddingLeft: 8,
      borderLeft: "1px solid var(--border-default)",
      height: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "erp-avatar",
    style: {
      width: 32,
      height: 32,
      fontSize: 12
    }
  }, "HM"), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 500,
      color: "var(--text-primary)"
    }
  }, "Hassan Mahmood"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: "var(--text-muted)"
    }
  }, "Finance Admin"))));
};
window.Topbar = Topbar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/erp-app/Topbar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/erp-app/data.js
try { (() => {
// data.js — sample fixtures
window.OB_DATA = {
  employees: [{
    id: "EMP-04219",
    name: "Asad Rauf",
    dept: "Finance",
    status: "approved",
    net: "PKR 184,000",
    avatar: "AR",
    tint: ["#EEF2FF", "#3730A3"]
  }, {
    id: "EMP-04220",
    name: "Nimra Khan",
    dept: "HR",
    status: "pending",
    net: "PKR 142,500",
    avatar: "NK",
    tint: ["#FEF3C7", "#92400E"]
  }, {
    id: "EMP-04221",
    name: "Usman Haider",
    dept: "Business Ops",
    status: "paid",
    net: "PKR 220,000",
    avatar: "UH",
    tint: ["#DCFCE7", "#166534"]
  }, {
    id: "EMP-04222",
    name: "Sana Farooq",
    dept: "Compliance",
    status: "suspended",
    net: "PKR 95,000",
    avatar: "SF",
    tint: ["#FFE4E6", "#9F1239"]
  }, {
    id: "EMP-04223",
    name: "Bilal Anwar",
    dept: "Finance",
    status: "approved",
    net: "PKR 168,500",
    avatar: "BA",
    tint: ["#DBEAFE", "#1E40AF"]
  }, {
    id: "EMP-04224",
    name: "Hira Mansoor",
    dept: "Business Ops",
    status: "draft",
    net: "PKR 110,000",
    avatar: "HM",
    tint: ["#FED7AA", "#9A3412"]
  }, {
    id: "EMP-04225",
    name: "Talha Sajid",
    dept: "IT",
    status: "approved",
    net: "PKR 198,000",
    avatar: "TS",
    tint: ["#CFFAFE", "#155E75"]
  }],
  sellers: [{
    id: "SLR-1042",
    name: "Lahore Linens Co.",
    reg: "08 May 2026",
    category: "Home & Living",
    status: "approved",
    gmv: "PKR 4.2M"
  }, {
    id: "SLR-1043",
    name: "Karachi Tech Hub",
    reg: "11 May 2026",
    category: "Electronics",
    status: "pending",
    gmv: "PKR 1.8M"
  }, {
    id: "SLR-1044",
    name: "Islamabad Imports",
    reg: "14 May 2026",
    category: "Cosmetics",
    status: "rejected",
    gmv: "—"
  }, {
    id: "SLR-1045",
    name: "Faisal Fabrics",
    reg: "19 May 2026",
    category: "Apparel",
    status: "approved",
    gmv: "PKR 12.1M"
  }, {
    id: "SLR-1046",
    name: "Multan Mango Mart",
    reg: "22 May 2026",
    category: "Groceries",
    status: "draft",
    gmv: "PKR 0.4M"
  }, {
    id: "SLR-1047",
    name: "Peshawar Plastics",
    reg: "24 May 2026",
    category: "Industrial",
    status: "pending",
    gmv: "PKR 2.7M"
  }],
  statements: [{
    id: "ST-2419",
    date: "27 May 2026",
    buyer: "Lahore Linens Co.",
    seller: "Faisal Fabrics",
    amount: "PKR 84,500",
    status: "paid"
  }, {
    id: "ST-2420",
    date: "27 May 2026",
    buyer: "Karachi Tech Hub",
    seller: "Islamabad Imports",
    amount: "PKR 218,000",
    status: "pending"
  }, {
    id: "ST-2421",
    date: "26 May 2026",
    buyer: "Faisal Fabrics",
    seller: "Multan Mango Mart",
    amount: "PKR 11,200",
    status: "approved"
  }, {
    id: "ST-2422",
    date: "26 May 2026",
    buyer: "Peshawar Plastics",
    seller: "Karachi Tech Hub",
    amount: "PKR 64,750",
    status: "rejected"
  }, {
    id: "ST-2423",
    date: "25 May 2026",
    buyer: "Lahore Linens Co.",
    seller: "Faisal Fabrics",
    amount: "PKR 132,400",
    status: "paid"
  }]
};

// Module config (must mirror tokens.css)
window.OB_MODULES = [{
  id: "workspace",
  name: "My Workspace",
  accent: "hr",
  gradient: "linear-gradient(135deg,#4F46E5,#7C3AED)",
  icon: "grid"
}, {
  id: "hr",
  name: "HR & Administration",
  accent: "hr",
  gradient: "linear-gradient(135deg,#4F46E5,#7C3AED)",
  icon: "users"
}, {
  id: "finance",
  name: "Finance & Accounting",
  accent: "fin",
  gradient: "linear-gradient(135deg,#0EA5E9,#10B981)",
  icon: "wallet"
}, {
  id: "ops",
  name: "Business Operations",
  accent: "ops",
  gradient: "linear-gradient(135deg,#F97316,#F59E0B)",
  icon: "shop"
}, {
  id: "governance",
  name: "Corporate Governance",
  accent: "gov",
  gradient: "linear-gradient(135deg,#334155,#10B981)",
  icon: "shield"
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/erp-app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.DashboardLayout = __ds_scope.DashboardLayout;

__ds_ns.Sidebar = __ds_scope.Sidebar;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.ModuleCard = __ds_scope.ModuleCard;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.Dropdown = __ds_scope.Dropdown;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.Loader = __ds_scope.Loader;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

__ds_ns.DynamicFieldSection = __ds_scope.DynamicFieldSection;

__ds_ns.ICON_FOR = __ds_scope.ICON_FOR;

})();
