---
name: offerberries-design
description: Use this skill to generate well-branded interfaces and assets for OfferBerries ERP, a multi-module enterprise resource planning suite for Pakistani ecommerce marketplace operations. Use for production code or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

Key files:
- `README.md` — full system overview, content tone, visual foundations, iconography
- `colors_and_type.css` — the single source of truth for tokens (colors, type scale, spacing, radii, shadows, base component classes)
- `preview/` — visual reference cards (open these to see what each token looks like)
- `ui_kits/erp-app/` — copy these JSX components when scaffolding a new screen

The OfferBerries look is desktop-first enterprise SaaS: a persistent dark `#0F172A` sidebar, white cards on `#F8FAFC`, Plus Jakarta Sans typography restricted to weights 400/500, and module-coded accent gradients (HR indigo→violet, Finance sky→emerald, Ops orange→amber). Tables are Supabase-dense with 13px cells. Status badges follow a fixed 9-variant taxonomy. No emoji, no illustrations, no decorative gradients on chrome — the gradient lives only on each module's dashboard hero strip and primary button.

If creating visual artifacts (slides, mocks, throwaway prototypes), copy `colors_and_type.css` and import it at the top of your HTML, then build with the `.erp-*` utility classes already defined inside it. If working on production code, the original repo at `IhsanKhann/Backend-offerB` has the full Tailwind config and live components — these tokens map 1:1.

If the user invokes this skill without any other guidance, ask them what they want to build (which module? full page, single component, or a flow across modules?), then act as an expert designer who outputs HTML artifacts or production code, depending on the need.
