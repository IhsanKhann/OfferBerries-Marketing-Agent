// src/components/ui/index.jsx
// ============================================================
// OfferBerries ERP — Core UI Components
// Button, Badge, Input, Card, Modal, Dropdown, Table, Avatar
// ============================================================

import React, { useState, useRef, useEffect } from "react";
import { X, ChevronDown, Loader2 } from "lucide-react";

// ─────────────────────────────────────────────────────────────
// BUTTON
// ─────────────────────────────────────────────────────────────
/**
 * @param {'primary'|'outline'|'ghost'|'danger'} variant
 * @param {'hr'|'fin'|'ops'} module  – controls gradient for 'primary'
 * @param {'sm'|'md'|'lg'} size
 */
export const Button = ({
  children,
  variant = "primary",
  module = "hr",
  size = "md",
  loading = false,
  disabled = false,
  className = "",
  ...props
}) => {
  const gradients = {
    hr:  "bg-hr-gradient",
    fin: "bg-fin-gradient",
    ops: "bg-ops-gradient",
  };

  const sizes = {
    sm: "px-3 py-1.5 text-caption",
    md: "px-4 py-2 text-body",
    lg: "px-5 py-2.5 text-h3",
  };

  const base = `
    inline-flex items-center justify-center gap-2
    font-medium rounded-md
    transition-all duration-150
    active:scale-97
    disabled:opacity-50 disabled:cursor-not-allowed
    select-none
  `;

  const variants = {
    primary: `${gradients[module]} text-white hover:opacity-88`,
    outline: `bg-transparent border-1.5 border-${module}-from text-${module}-text hover:bg-${module}-bg`,
    ghost:   "bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100",
    danger:  "bg-red-50 border border-red-200 text-red-700 hover:bg-red-100",
  };

  return (
    <button
      className={`${base} ${sizes[size]} ${variants[variant]} ${className}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading && <Loader2 size={14} className="animate-spin" />}
      {children}
    </button>
  );
};

// ─────────────────────────────────────────────────────────────
// BADGE
// ─────────────────────────────────────────────────────────────
const BADGE_STYLES = {
  approved:   "bg-green-50   text-green-700  border-green-200",
  pending:    "bg-orange-50  text-orange-700 border-orange-200",
  rejected:   "bg-red-50     text-red-700    border-red-200",
  draft:      "bg-blue-50    text-blue-700   border-blue-200",
  suspended:  "bg-purple-50  text-purple-700 border-purple-200",
  blocked:    "bg-slate-900  text-slate-300  border-slate-700",
  terminated: "bg-red-50     text-red-800    border-red-300",
  paid:       "bg-green-50   text-green-700  border-emerald-400",
  restored:   "bg-teal-50    text-teal-700   border-teal-200",
  active:     "bg-green-50   text-green-700  border-green-200",
  inactive:   "bg-slate-50   text-slate-500  border-slate-200",
};

const STATUS_DOT = {
  approved:   "bg-green-500",
  active:     "bg-green-500",
  paid:       "bg-emerald-500",
  pending:    "bg-orange-400",
  rejected:   "bg-red-500",
  terminated: "bg-red-700",
  suspended:  "bg-purple-500",
  blocked:    "bg-slate-400",
  draft:      "bg-blue-500",
  restored:   "bg-teal-500",
};

export const Badge = ({ children, status, className = "" }) => {
  const key = (status || "draft").toLowerCase();
  const style = BADGE_STYLES[key] || BADGE_STYLES.draft;
  const dot = STATUS_DOT[key];

  return (
    <span
      className={`
        inline-flex items-center gap-1.5
        px-2 py-0.5 rounded-full text-2xs font-medium
        border
        ${style} ${className}
      `}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />}
      {children}
    </span>
  );
};

// ─────────────────────────────────────────────────────────────
// INPUT
// ─────────────────────────────────────────────────────────────
export const Input = ({
  label,
  error,
  hint,
  className = "",
  wrapperClassName = "",
  ...props
}) => (
  <div className={`flex flex-col gap-1.5 ${wrapperClassName}`}>
    {label && (
      <label className="text-label text-slate-700 font-medium">{label}</label>
    )}
    <input
      className={`
        w-full px-3 py-2.5 min-h-[40px]
        text-body text-slate-800
        bg-white border border-slate-200 rounded-md
        placeholder:text-slate-400
        transition-all duration-150
        focus:outline-none focus:border-indigo-500 focus:shadow-focus
        disabled:bg-slate-50 disabled:text-slate-400 disabled:cursor-not-allowed
        ${error ? "border-red-400 focus:shadow-focus-danger" : ""}
        ${className}
      `}
      {...props}
    />
    {error && <p className="text-caption text-red-600">{error}</p>}
    {hint && !error && <p className="text-caption text-slate-400">{hint}</p>}
  </div>
);

export const Select = ({
  label,
  error,
  children,
  className = "",
  wrapperClassName = "",
  ...props
}) => (
  <div className={`flex flex-col gap-1.5 ${wrapperClassName}`}>
    {label && (
      <label className="text-label text-slate-700 font-medium">{label}</label>
    )}
    <select
      className={`
        w-full px-3 py-2.5 min-h-[40px]
        text-body text-slate-800
        bg-white border border-slate-200 rounded-md
        transition-all duration-150
        focus:outline-none focus:border-indigo-500 focus:shadow-focus
        ${error ? "border-red-400" : ""}
        ${className}
      `}
      {...props}
    >
      {children}
    </select>
    {error && <p className="text-caption text-red-600">{error}</p>}
  </div>
);

export const Textarea = ({
  label,
  error,
  className = "",
  wrapperClassName = "",
  ...props
}) => (
  <div className={`flex flex-col gap-1.5 ${wrapperClassName}`}>
    {label && (
      <label className="text-label text-slate-700 font-medium">{label}</label>
    )}
    <textarea
      className={`
        w-full px-3 py-2.5
        text-body text-slate-800
        bg-white border border-slate-200 rounded-md
        placeholder:text-slate-400
        transition-all duration-150
        focus:outline-none focus:border-indigo-500 focus:shadow-focus
        resize-y min-h-[80px]
        ${error ? "border-red-400" : ""}
        ${className}
      `}
      {...props}
    />
    {error && <p className="text-caption text-red-600">{error}</p>}
  </div>
);

// ─────────────────────────────────────────────────────────────
// CARD
// ─────────────────────────────────────────────────────────────
export const Card = ({
  children,
  className = "",
  hover = false,
  padding = "p-4",
  ...props
}) => (
  <div
    className={`
      bg-canvas border border-slate-100 rounded-xl shadow-xs
      ${hover ? "hover:-translate-y-0.5 hover:shadow-md transition-all duration-150 cursor-pointer" : ""}
      ${padding} ${className}
    `}
    {...props}
  >
    {children}
  </div>
);

/**
 * Module hero card with gradient background + decorative circles
 */
export const ModuleCard = ({
  module = "hr",
  children,
  className = "",
  ...props
}) => {
  const gradients = {
    hr:  "bg-hr-gradient",
    fin: "bg-fin-gradient",
    ops: "bg-ops-gradient",
  };

  return (
    <div
      className={`
        relative overflow-hidden rounded-xl text-white
        ${gradients[module]} shadow-md
        p-5 ${className}
      `}
      {...props}
    >
      {/* Decorative circles */}
      <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-white opacity-5" />
      <div className="absolute -bottom-6 -left-6 w-24 h-24 rounded-full bg-white opacity-5" />
      <div className="relative z-10">{children}</div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// STAT CARD
// ─────────────────────────────────────────────────────────────
export const StatCard = ({
  label,
  value,
  trend,
  trendLabel,
  icon,
  module = "hr",
  className = "",
}) => {
  const tints = {
    hr:  "bg-indigo-50 border-indigo-100",
    fin: "bg-sky-50    border-sky-100",
    ops: "bg-orange-50 border-orange-100",
  };

  const textColors = {
    hr:  "text-indigo-800",
    fin: "text-sky-800",
    ops: "text-orange-800",
  };

  const labelColors = {
    hr:  "text-indigo-600",
    fin: "text-sky-600",
    ops: "text-orange-600",
  };

  const trendColor =
    trend === undefined ? "" :
    trend > 0 ? "text-green-600" :
    trend < 0 ? "text-red-500" :
    "text-slate-500";

  return (
    <div
      className={`
        rounded-xl border p-4 flex items-start justify-between gap-3
        ${tints[module]} ${className}
      `}
    >
      <div className="flex-1 min-w-0">
        <p className={`text-2xs uppercase tracking-wider mb-1 ${labelColors[module]}`}>
          {label}
        </p>
        <p className={`text-display font-medium leading-none ${textColors[module]}`}>
          {value}
        </p>
        {trend !== undefined && (
          <p className={`text-caption mt-1.5 ${trendColor}`}>
            {trend > 0 ? "▲" : trend < 0 ? "▼" : "—"}{" "}
            {trendLabel || `${Math.abs(trend)}%`}
          </p>
        )}
      </div>
      {icon && (
        <div className={`p-2 rounded-lg ${tints[module]} opacity-80`}>
          {icon}
        </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// AVATAR
// ─────────────────────────────────────────────────────────────
export const Avatar = ({
  src,
  name = "",
  size = "md",
  module = "hr",
  className = "",
}) => {
  const sizes = { sm: "w-8 h-8 text-xs", md: "w-11 h-11 text-sm", lg: "w-16 h-16 text-xl" };
  const gradients = {
    hr:  "from-indigo-500 to-violet-600",
    fin: "from-sky-500 to-emerald-500",
    ops: "from-orange-500 to-amber-400",
  };
  const initials = name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();

  return src ? (
    <img
      src={src}
      alt={name}
      className={`rounded-full object-cover ${sizes[size]} ${className}`}
    />
  ) : (
    <div
      className={`
        rounded-full flex items-center justify-center text-white font-medium
        bg-gradient-to-br ${gradients[module]}
        ${sizes[size]} ${className}
      `}
    >
      {initials || "?"}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// MODAL
// ─────────────────────────────────────────────────────────────
export const Modal = ({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  size = "md",
  className = "",
}) => {
  if (!open) return null;

  const sizes = {
    sm:   "max-w-md",
    md:   "max-w-2xl",
    lg:   "max-w-4xl",
    xl:   "max-w-6xl",
    full: "max-w-[95vw]",
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4
                 bg-black/40 backdrop-blur-sm"
      onClick={(e) => e.target === e.currentTarget && onClose?.()}
    >
      <div
        className={`
          bg-canvas w-full ${sizes[size]} rounded-2xl shadow-lg
          flex flex-col max-h-[90vh]
          ${className}
        `}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-slate-100 flex-shrink-0">
          <div>
            {title && (
              <h2 className="text-h2 text-slate-900">{title}</h2>
            )}
            {subtitle && (
              <p className="text-caption text-slate-500 mt-0.5">{subtitle}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md text-slate-400 hover:text-slate-700
                       hover:bg-slate-100 transition-all ml-4"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto erp-scroll p-6">
          {children}
        </div>

        {/* Footer */}
        {footer && (
          <div className="flex justify-end gap-2 p-6 border-t border-slate-100 flex-shrink-0">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// DROPDOWN MENU
// ─────────────────────────────────────────────────────────────
export const Dropdown = ({ trigger, items = [], align = "right" }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div ref={ref} className="relative inline-block">
      <div onClick={() => setOpen((o) => !o)}>{trigger}</div>

      {open && (
        <div
          className={`
            absolute z-50 mt-1 w-48 bg-canvas rounded-lg border border-slate-100
            shadow-md py-1 overflow-hidden
            ${align === "right" ? "right-0" : "left-0"}
          `}
        >
          {items.map((item, idx) =>
            item.separator ? (
              <div key={idx} className="my-1 border-t border-slate-100" />
            ) : (
              <button
                key={idx}
                onClick={() => { item.onClick?.(); setOpen(false); }}
                className={`
                  w-full text-left px-4 py-2 text-caption
                  transition-colors duration-100
                  ${item.danger
                    ? "text-red-600 hover:bg-red-50"
                    : "text-slate-700 hover:bg-subtle"
                  }
                  ${item.disabled ? "opacity-40 cursor-not-allowed" : ""}
                  flex items-center gap-2
                `}
                disabled={item.disabled}
              >
                {item.icon && <span className="opacity-60">{item.icon}</span>}
                {item.label}
              </button>
            )
          )}
        </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// TABLE
// ─────────────────────────────────────────────────────────────
export const Table = ({ columns = [], data = [], loading = false, emptyMessage = "No data found" }) => (
  <div className="w-full overflow-x-auto rounded-xl border border-slate-100 bg-canvas">
    <table className="w-full text-left border-collapse">
      <thead>
        <tr className="bg-subtle border-b border-slate-100">
          {columns.map((col, i) => (
            <th
              key={i}
              className="px-4 py-3 text-2xs uppercase tracking-wider text-slate-400 font-medium"
              style={{ width: col.width }}
            >
              {col.header}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {loading ? (
          <tr>
            <td colSpan={columns.length} className="px-4 py-12 text-center">
              <div className="flex justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-indigo-500 border-t-transparent" />
              </div>
            </td>
          </tr>
        ) : data.length === 0 ? (
          <tr>
            <td colSpan={columns.length} className="px-4 py-12 text-center text-caption text-slate-400 italic">
              {emptyMessage}
            </td>
          </tr>
        ) : (
          data.map((row, ri) => (
            <tr key={ri} className="border-b border-slate-50 hover:bg-subtle/60 transition-colors">
              {columns.map((col, ci) => (
                <td key={ci} className="px-4 py-3 text-caption text-slate-700">
                  {col.render ? col.render(row[col.key], row) : row[col.key] ?? "—"}
                </td>
              ))}
            </tr>
          ))
        )}
      </tbody>
    </table>
  </div>
);

// ─────────────────────────────────────────────────────────────
// LOADER
// ─────────────────────────────────────────────────────────────
export const Loader = ({ fullPage = false }) => (
  <div className={`flex justify-center items-center ${fullPage ? "min-h-screen" : "min-h-[60vh]"}`}>
    <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-500 border-t-transparent" />
  </div>
);

// ─────────────────────────────────────────────────────────────
// SECTION HEADER
// ─────────────────────────────────────────────────────────────
export const SectionHeader = ({ title, subtitle, actions }) => (
  <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
    <div>
      <h1 className="text-h1 text-slate-900">{title}</h1>
      {subtitle && <p className="text-caption text-slate-500 mt-0.5">{subtitle}</p>}
    </div>
    {actions && <div className="flex items-center gap-2">{actions}</div>}
  </div>
);

// ─────────────────────────────────────────────────────────────
// DYNAMIC FIELD SECTION (allowances / deductions)
// ─────────────────────────────────────────────────────────────
export const DynamicFieldSection = ({ title, items = [], setItems, isEditing = true }) => (
  <div className="rounded-xl border border-slate-100 bg-subtle/40 p-4 mb-4">
    <div className="flex items-center justify-between mb-3">
      <h3 className="text-h3 text-slate-800">{title}</h3>
      {isEditing && (
        <Button
          size="sm"
          variant="outline"
          module="hr"
          type="button"
          onClick={() => setItems([...items, { name: "", type: "fixed", value: 0 }])}
        >
          + Add
        </Button>
      )}
    </div>

    {items.length === 0 && (
      <p className="text-caption text-slate-400 italic">No {title.toLowerCase()} defined.</p>
    )}

    <div className="space-y-2">
      {items.map((item, idx) => (
        <div key={idx} className="flex gap-2 items-center bg-canvas rounded-lg p-2 border border-slate-100">
          {isEditing ? (
            <>
              <Input
                className="flex-1"
                placeholder="Name"
                value={item.name}
                onChange={(e) => {
                  const u = [...items]; u[idx].name = e.target.value; setItems(u);
                }}
              />
              <Select
                className="w-32"
                value={item.type}
                onChange={(e) => {
                  const u = [...items]; u[idx].type = e.target.value; setItems(u);
                }}
              >
                <option value="fixed">Fixed</option>
                <option value="percentage">%</option>
              </Select>
              <Input
                type="number"
                className="w-28"
                value={item.value}
                onChange={(e) => {
                  const u = [...items]; u[idx].value = Number(e.target.value); setItems(u);
                }}
              />
              <button
                type="button"
                className="p-1.5 rounded-md text-red-400 hover:text-red-600 hover:bg-red-50 transition-all"
                onClick={() => setItems(items.filter((_, i) => i !== idx))}
              >
                <X size={14} />
              </button>
            </>
          ) : (
            <>
              <span className="flex-1 text-body font-medium text-slate-800">{item.name}</span>
              <span className="capitalize text-caption text-slate-500">{item.type}</span>
              <span className="text-body font-medium text-slate-800 text-right w-28">
                {item.type === "percentage" ? `${item.value}%` : `PKR ${item.value}`}
              </span>
            </>
          )}
        </div>
      ))}
    </div>
  </div>
);

export default {
  Button, Badge, Input, Select, Textarea,
  Card, ModuleCard, StatCard,
  Avatar, Modal, Dropdown, Table,
  Loader, SectionHeader, DynamicFieldSection,
};