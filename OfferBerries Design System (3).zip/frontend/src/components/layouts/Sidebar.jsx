// src/components/layout/Sidebar.jsx
import { useState, useEffect } from "react";
import { ChevronRight, ChevronDown, ChevronLeft, Building2, Users, Layers, Info } from "lucide-react";
import api from "@api/axios.js";

/* ─── Module brand config ── */
const MODULE_CONFIG = {
  AdminDashboard:      { label: "HR Module",    gradient: "var(--hr-gradient)"  },
  SalaryDashboard:     { label: "Finance",      gradient: "var(--fin-gradient)" },
  PermissionsManager:  { label: "HR Module",    gradient: "var(--hr-gradient)"  },
  "Sellers Dashboard": { label: "Business Ops", gradient: "var(--ops-gradient)" },
  "Pending Account Statements": { label: "Business Ops", gradient: "var(--ops-gradient)" },
  "Paid Account Statements":    { label: "Business Ops", gradient: "var(--ops-gradient)" },
  default:             { label: "ERP Suite",    gradient: "var(--hr-gradient)"  },
};

const DEPT_COLORS = {
  Finance:           "var(--fin-accent)",
  HR:                "var(--hr-accent)",
  BusinessOperation: "var(--ops-accent)",
  IT:                "#06B6D4",
  Compliance:        "#F59E0B",
  All:               "var(--text-muted)",
};

/* ─── Tooltip ── */
const Tooltip = ({ text, children }) => {
  const [show, setShow] = useState(false);
  return (
    <div
      style={{ position: "relative" }}
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      {children}
      {show && (
        <div
          style={{
            position: "absolute",
            left: "calc(100% + 10px)",
            top: "50%",
            transform: "translateY(-50%)",
            background: "#1A2236",
            border: "1px solid rgba(255,255,255,.1)",
            color: "var(--text-inverse)",
            fontSize: "var(--text-xs)",
            fontWeight: 500,
            padding: "6px 12px",
            borderRadius: "var(--radius-md)",
            whiteSpace: "nowrap",
            boxShadow: "var(--shadow-lg)",
            zIndex: "var(--z-tooltip)",
          }}
        >
          {text}
        </div>
      )}
    </div>
  );
};

/* ─── Org Tree Node ── */
const CompactTreeNode = ({ node, level = 0, onNodeSelect, selectedId }) => {
  const [expanded, setExpanded] = useState(level < 1);
  const hasChildren = node.children?.length > 0;
  const isSelected = selectedId === node._id;
  const color = DEPT_COLORS[node.departmentCode] || "var(--text-muted)";

  return (
    <div>
      <div
        onClick={() => onNodeSelect(node, !hasChildren)}
        style={{
          display: "flex", alignItems: "center",
          padding: `6px ${8 + level * 12}px 6px 8px`,
          borderRadius: "var(--radius-sm)",
          cursor: "pointer",
          background: isSelected ? "rgba(99,102,241,0.14)" : "transparent",
          transition: "background var(--transition-fast)",
          marginBottom: 1,
          gap: "var(--space-2)",
        }}
        onMouseEnter={(e) => { if (!isSelected) e.currentTarget.style.background = "rgba(255,255,255,.05)"; }}
        onMouseLeave={(e) => { if (!isSelected) e.currentTarget.style.background = "transparent"; }}
      >
        <button
          onClick={(e) => { e.stopPropagation(); if (hasChildren) setExpanded(!expanded); }}
          style={{
            width: 16, height: 16, display: "flex", alignItems: "center",
            justifyContent: "center", background: "none", border: "none",
            cursor: hasChildren ? "pointer" : "default",
            color: "rgba(255,255,255,.3)", flexShrink: 0,
          }}
        >
          {hasChildren ? (expanded ? <ChevronDown size={11} /> : <ChevronRight size={11} />) : <span style={{ width: 10 }} />}
        </button>
        <span style={{ color, flexShrink: 0 }}>
          {hasChildren ? <Building2 size={12} /> : <Users size={12} />}
        </span>
        <span
          style={{
            fontSize: "var(--text-xs)",
            color: isSelected ? "var(--sidebar-text-active)" : "var(--sidebar-text)",
            fontWeight: isSelected ? 600 : 400,
            flex: 1, overflow: "hidden",
            textOverflow: "ellipsis", whiteSpace: "nowrap",
          }}
        >
          {node.name}
        </span>
      </div>

      {expanded && hasChildren && (
        <div>
          {node.children.map((child) => (
            <CompactTreeNode key={child._id} node={child} level={level + 1}
              onNodeSelect={onNodeSelect} selectedId={selectedId} />
          ))}
        </div>
      )}
    </div>
  );
};

/* ─── Mini Org Tree ── */
const MiniHierarchyTree = ({ onNodeSelect, isCollapsed }) => {
  const [treeData, setTreeData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const [isExpanded, setIsExpanded] = useState(true);

  useEffect(() => { if (!isCollapsed) fetchTree(); }, [isCollapsed]);

  const fetchTree = async () => {
    try {
      setLoading(true);
      const res = await api.get("/org-units");
      const data = await res.data;
      setTreeData(Array.isArray(data) ? data : data.data || [data]);
    } catch { /* silent */ }
    finally { setLoading(false); }
  };

  if (isCollapsed) return null;

  return (
    <div style={{ borderBottom: "1px solid var(--sidebar-border)" }}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        style={{
          width: "100%", padding: "10px 16px",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          background: "none", border: "none", cursor: "pointer",
          color: "var(--sidebar-text)", fontSize: "var(--text-xs)", fontWeight: 600,
        }}
      >
        <span style={{ display: "flex", alignItems: "center", gap: "var(--space-2)" }}>
          <Building2 size={13} /> Organization
        </span>
        {isExpanded ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
      </button>

      {isExpanded && (
        <div
          style={{ maxHeight: 240, overflowY: "auto", padding: "4px 8px 8px" }}
          className="erp-scroll"
        >
          {loading ? (
            <div style={{ display: "flex", justifyContent: "center", padding: "12px 0" }}>
              <div style={{
                width: 18, height: 18, borderRadius: "50%",
                border: "2px solid var(--hr-accent)", borderTopColor: "transparent",
                animation: "spin 0.8s linear infinite",
              }} />
            </div>
          ) : treeData.map((node) => (
            <CompactTreeNode
              key={node._id}
              node={node}
              onNodeSelect={(n, leaf) => { setSelectedId(n._id); onNodeSelect(n, leaf); }}
              selectedId={selectedId}
            />
          ))}
        </div>
      )}
    </div>
  );
};

/* ─── MAIN SIDEBAR ── */
const Sidebar = ({ fetchEmployeesByNode, navItems = [], title }) => {
  const [activeItem, setActiveItem] = useState(null);
  const [isCollapsed, setIsCollapsed] = useState(false);

  const config = MODULE_CONFIG[title] || MODULE_CONFIG.default;

  const handleNav = (item) => {
    setActiveItem(item.name);
    if (item.path) window.location.href = item.path;
    else if (item.action) item.action();
  };

  return (
    <div
      style={{
        width: isCollapsed ? "var(--sidebar-collapsed)" : "var(--sidebar-width)",
        flexShrink: 0,
        background: "var(--sidebar-bg)",
        borderRight: "1px solid var(--sidebar-border)",
        height: "100vh",
        position: "sticky",
        top: 0,
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        transition: "width var(--transition-slow)",
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: "18px 14px 14px",
          borderBottom: "1px solid var(--sidebar-border)",
          display: "flex",
          alignItems: "center",
          justifyContent: isCollapsed ? "center" : "space-between",
          gap: "var(--space-2)",
          flexShrink: 0,
        }}
      >
        {!isCollapsed && (
          <div style={{ display: "flex", alignItems: "center", gap: "var(--space-2)", overflow: "hidden" }}>
            <div
              style={{
                width: 30, height: 30, borderRadius: "var(--radius-md)",
                background: config.gradient,
                display: "flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <Layers size={15} color="white" />
            </div>
            <div>
              <div style={{ fontSize: "var(--text-sm)", fontWeight: 700, color: "var(--text-inverse)", whiteSpace: "nowrap" }}>
                {title}
              </div>
              <div style={{ fontSize: "var(--text-2xs)", color: "var(--sidebar-section)", fontWeight: 600, letterSpacing: "0.05em", textTransform: "uppercase" }}>
                {config.label}
              </div>
            </div>
          </div>
        )}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          style={{
            background: "none", border: "none", cursor: "pointer",
            color: "var(--sidebar-text)", padding: "var(--space-1)", borderRadius: "var(--radius-sm)",
            display: "flex", alignItems: "center", flexShrink: 0,
            transition: "color var(--transition-fast), background var(--transition-fast)",
          }}
          onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(255,255,255,.07)"; e.currentTarget.style.color = "var(--text-inverse)"; }}
          onMouseLeave={(e) => { e.currentTarget.style.background = "none"; e.currentTarget.style.color = "var(--sidebar-text)"; }}
        >
          {isCollapsed ? <ChevronRight size={17} /> : <ChevronLeft size={17} />}
        </button>
      </div>

      {/* Scrollable body */}
      <div style={{ flex: 1, overflowY: "auto", overflowX: "hidden" }} className="erp-scroll">

        {/* Org tree — AdminDashboard only */}
        {title === "AdminDashboard" && fetchEmployeesByNode && (
          <MiniHierarchyTree onNodeSelect={fetchEmployeesByNode} isCollapsed={isCollapsed} />
        )}

        {/* Permission sync notice */}
        {title === "PermissionsManager" && !isCollapsed && (
          <div
            style={{
              margin: "var(--space-2) var(--space-2)",
              padding: "var(--space-2) var(--space-3)",
              background: "rgba(245,158,11,.07)",
              borderRadius: "var(--radius-md)",
              border: "1px solid rgba(245,158,11,.15)",
              display: "flex", alignItems: "flex-start", gap: "var(--space-2)",
            }}
          >
            <Info size={13} color="#FBBF24" style={{ flexShrink: 0, marginTop: 1 }} />
            <p style={{ fontSize: "var(--text-2xs)", color: "#FBBF24", lineHeight: 1.5, margin: 0 }}>
              Permission sync active. Changes propagate in ~5 min.
            </p>
          </div>
        )}

        {/* Nav items */}
        <div style={{ padding: "var(--space-2)" }}>
          {!isCollapsed && (
            <div
              style={{
                fontSize: "var(--text-2xs)", fontWeight: 700,
                color: "var(--sidebar-section)",
                textTransform: "uppercase", letterSpacing: "0.1em",
                padding: "6px var(--space-2) 4px",
              }}
            >
              Menu
            </div>
          )}

          {navItems.map((item) => {
            const isActive = activeItem === item.name;
            const btn = (
              <button
                key={item.name}
                onClick={() => handleNav(item)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: isCollapsed ? 0 : "var(--space-2)",
                  justifyContent: isCollapsed ? "center" : "flex-start",
                  width: "100%",
                  padding: isCollapsed ? "var(--space-2)" : "9px var(--space-2)",
                  borderRadius: "var(--radius-md)",
                  border: isActive ? `none` : "none",
                  borderLeft: isActive ? `2px solid var(--sidebar-active-bar)` : "2px solid transparent",
                  cursor: "pointer",
                  background: isActive ? "var(--sidebar-active-bg)" : "transparent",
                  color: isActive ? "var(--sidebar-text-active)" : "var(--sidebar-text)",
                  fontSize: "var(--text-sm)",
                  fontWeight: isActive ? 600 : 500,
                  textAlign: "left",
                  marginBottom: 2,
                  transition: "background var(--transition-fast), color var(--transition-fast)",
                  overflow: "hidden",
                  paddingLeft: isCollapsed ? undefined : isActive ? "calc(var(--space-2) - 2px)" : "var(--space-2)",
                }}
                onMouseEnter={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.background = "rgba(255,255,255,.05)";
                    e.currentTarget.style.color = "var(--sidebar-text-hover)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.background = "transparent";
                    e.currentTarget.style.color = "var(--sidebar-text)";
                  }
                }}
              >
                <span style={{ flexShrink: 0, display: "flex", alignItems: "center" }}>
                  {item.icon}
                </span>
                {!isCollapsed && (
                  <span style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {item.name}
                  </span>
                )}
              </button>
            );

            return isCollapsed
              ? <Tooltip key={item.name} text={item.name}>{btn}</Tooltip>
              : <div key={item.name}>{btn}</div>;
          })}
        </div>
      </div>

      {/* Footer */}
      <div
        style={{
          padding: "var(--space-3) var(--space-4)",
          borderTop: "1px solid var(--sidebar-border)",
          display: "flex",
          alignItems: "center",
          justifyContent: isCollapsed ? "center" : "flex-start",
        }}
      >
        {isCollapsed ? (
          <Tooltip text="Enterprise Suite v2.0">
            <div style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--sidebar-section)" }} />
          </Tooltip>
        ) : (
          <p style={{ fontSize: "var(--text-2xs)", color: "var(--sidebar-section)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em", margin: 0 }}>
            Enterprise Suite v2.0
          </p>
        )}
      </div>
    </div>
  );
};

export default Sidebar;