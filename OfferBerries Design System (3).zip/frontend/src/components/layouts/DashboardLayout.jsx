// src/components/layout/DashboardLayout.jsx
// ============================================================
// Universal layout wrapper for all ERP module pages.
// Usage:
//   <DashboardLayout sidebar={<Sidebar ... />} title="My Page">
//     {children}
//   </DashboardLayout>
// ============================================================

import React from "react";

const DashboardLayout = ({
  sidebar,
  children,
  className = "",
}) => (
  <div className={`flex min-h-screen bg-page ${className}`}>
    {/* Sticky Sidebar */}
    {sidebar && (
      <div className="sticky top-0 h-screen flex-shrink-0">
        {sidebar}
      </div>
    )}

    {/* Scrollable Main Area */}
    <main className="flex-1 overflow-y-auto erp-scroll">
      <div className="p-6 max-w-screen-2xl mx-auto">
        {children}
      </div>
    </main>
  </div>
);

export default DashboardLayout;