// toast-system/toast-variants.ts
// ---------------------------------------------------------------------------
// CVA variant system for the OfferBerries toast. Every visual axis (container
// surface, icon chip, accent rail) is a CVA recipe keyed off `ToastType`, so a
// new variant is one new key — never a new component.
// ---------------------------------------------------------------------------
import { cva, type VariantProps } from "class-variance-authority";
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Info,
  Loader2,
  Bell,
  Sparkles,
  type LucideIcon,
} from "lucide-react";

export type ToastType =
  | "success"
  | "error"
  | "warning"
  | "info"
  | "loading"
  | "default"
  | "custom";

/** Card container — the rounded-2xl glass surface. */
export const toastContainer = cva(
  [
    "group relative flex w-full items-start gap-3 overflow-hidden",
    "rounded-[18px] border p-[13px_14px]",
    "bg-canvas/95 supports-[backdrop-filter]:bg-canvas/80 backdrop-blur-sm backdrop-saturate-150",
    "border-border text-fg shadow-lg",
    "transition-[transform,opacity,filter] will-change-transform",
  ],
  {
    variants: {
      type: {
        success: "",
        error: "",
        warning: "",
        info: "",
        loading: "",
        default: "",
        custom: "p-3",
      },
    },
    defaultVariants: { type: "default" },
  },
);

/** Icon chip — soft tinted square behind the lucide glyph. */
export const toastIcon = cva(
  "flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-[9px]",
  {
    variants: {
      type: {
        success: "bg-success-bg text-success ring-4 ring-success/15",
        error:   "bg-danger-bg text-danger ring-4 ring-danger/15",
        warning: "bg-warning-bg text-warning ring-4 ring-warning/15",
        info:    "bg-info-bg text-info ring-4 ring-info/15",
        loading: "bg-info-bg text-indigo-500 ring-4 ring-indigo-500/15",
        default: "bg-page text-fg-secondary ring-4 ring-fg-muted/10",
        custom:  "hidden",
      },
    },
    defaultVariants: { type: "default" },
  },
);

/** Left accent rail — hidden for neutral/custom. */
export const toastAccent = cva("absolute inset-y-0 left-0 w-[3px]", {
  variants: {
    type: {
      success: "bg-success opacity-90",
      error:   "bg-danger opacity-90",
      warning: "bg-warning opacity-90",
      info:    "bg-info opacity-90",
      loading: "bg-indigo-500 opacity-90",
      default: "opacity-0",
      custom:  "opacity-0",
    },
  },
  defaultVariants: { type: "default" },
});

/** Timer / progress bar fill. */
export const toastBar = cva("h-full rounded-r-full opacity-50", {
  variants: {
    type: {
      success: "bg-success",
      error:   "bg-danger",
      warning: "bg-warning",
      info:    "bg-info",
      loading: "bg-indigo-500",
      default: "bg-fg-muted",
      custom:  "bg-fg-muted",
    },
  },
  defaultVariants: { type: "default" },
});

/** Map a variant to its lucide icon + whether it should spin. */
export const ICON_FOR: Record<ToastType, LucideIcon> = {
  success: CheckCircle2,
  error:   XCircle,
  warning: AlertTriangle,
  info:    Info,
  loading: Loader2,
  default: Bell,
  custom:  Sparkles,
};

export type ToastContainerVariants = VariantProps<typeof toastContainer>;
