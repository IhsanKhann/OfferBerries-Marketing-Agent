# OfferBerries Toast System

A production-ready toast notification layer for **React + TypeScript + Tailwind**, built on
[Sonner](https://sonner.emilkowal.ski) as the engine, [Framer Motion](https://www.framer.com/motion/)
for enter/exit motion, [CVA](https://cva.style) for the variant system, and
[lucide-react](https://lucide.dev) for icons. It is wired to the OfferBerries design tokens
(`colors_and_type.css`) so it themes light/dark automatically.

> Live, interactive reference: open **`Toast System.html`** in the project root — every variant,
> swipe-to-dismiss, pause/expand-on-hover, the animated timer bar, and all three positions are
> demonstrated there. These `.tsx`/`.ts` files are the drop-in version of that same behavior for a
> real codebase.

---

## File map

| File | Responsibility |
| --- | --- |
| `toast-variants.ts` | CVA variant definitions (container, icon, accent) + the `ToastType` union |
| `Toast.tsx` | The presentational toast card — icon, title, description, actions, progress, close |
| `toaster.tsx` | `<Toaster />` provider — configures Sonner, positions, motion, a11y |
| `toast.ts` | The type-safe `toast` utility API (`success`/`error`/`promise`/`custom`/…) |
| `use-toast.ts` | Optional hook re-export + helpers for reading/clearing the queue |
| `examples.tsx` | Copy-paste usage for all ten variants |

## Install

```bash
pnpm add sonner framer-motion class-variance-authority lucide-react clsx tailwind-merge
```

Tailwind: this package expects the OfferBerries CSS variables (from `colors_and_type.css`) to be
available globally, and the `.dark` class toggled on `<html>`. The Tailwind classes used resolve to
those vars via `theme.extend.colors` (see snippet at the bottom).

## Quick start

```tsx
// app/layout.tsx (or _app.tsx)
import { Toaster } from "@/components/toast/toaster";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
        <Toaster position="bottom-right" expand richColors closeButton />
      </body>
    </html>
  );
}
```

```tsx
// anywhere
import { toast } from "@/components/toast/toast";

toast.success("Statement #ST-2419 paid", {
  description: "PKR 84,500 transferred to Asad Rauf.",
});

toast.promise(runPayroll(), {
  loading: "Running payroll batch…",
  success: (n) => `Payroll closed · ${n} employees`,
  error: "Batch failed — rolled back",
});
```

---

## The ten variants

| # | Variant | API | Notes |
| --- | --- | --- | --- |
| 1 | Success | `toast.success(msg, opts)` | green accent, auto-dismiss 4s |
| 2 | Error | `toast.error(msg, opts)` | red accent, 5s, `role="alert"` |
| 3 | Warning | `toast.warning(msg, opts)` | amber accent, 4.5s |
| 4 | Info | `toast.info(msg, opts)` | blue accent, 4s |
| 5 | Loading / Promise | `toast.loading` / `toast.promise` | spinner, resolves in place |
| 6 | Action | `toast(msg, { action })` | CTA button(s) inside |
| 7 | Undo | `toast(msg, { action: { label: "Undo" } })` | reversible action pattern |
| 8 | Persistent | `toast(msg, { duration: Infinity })` | stays until dismissed |
| 9 | Progress | `toast(msg, { progress })` | live progress bar, update by id |
| 10 | Rich custom | `toast.custom(<JSX/>)` | fully custom layout |

---

## Interactions (all handled by Sonner + the card)

- **Swipe to dismiss** — drag a toast horizontally past threshold (Sonner built-in; touch + pointer).
- **Pause on hover** — hovering *any* toast pauses *every* timer in the stack.
- **Expand on hover** — set `expand` on `<Toaster>`; collapsed cards fan out to full height.
- **Auto-dismiss timer bar** — the `Toast` card renders an animated bar tied to `duration`.
- **Smart stacking** — newest in front; idle stack shows 3 peeking cards, rest collapse.
- **Positions** — `top-right`, `bottom-right`; below `640px` Sonner re-anchors to a full-width
  mobile bottom sheet automatically (we also force it via the `mobileOffset`/media logic in `toaster.tsx`).

## Accessibility

- The toast region is a polite live region; **errors** escalate to `role="alert"` /
  `aria-live="assertive"`, everything else is `role="status"` / `aria-live="polite"`.
- The close button has an `aria-label`; action buttons are real `<button>`s and fully keyboard
  reachable. Sonner exposes the stack to <kbd>F6</kbd> focus traversal and supports a configurable
  hotkey (default <kbd>⌥ + T</kbd>) to focus the region.
- Motion respects `prefers-reduced-motion` — Framer variants collapse to a simple opacity fade.
- Color is never the only signal: every variant pairs its accent with a distinct icon + label.
- Timer auto-dismiss pauses on hover **and** on focus-within, so keyboard users aren't rushed.

## Mobile behavior

- Under 640px the toaster becomes a bottom-anchored, full-width (minus 14px gutters) stack.
- Touch swipe-to-dismiss is enabled; tap targets (close, actions) stay ≥ 32px.
- Only the front toast shows its timer bar to reduce visual noise on small screens.

## Best practices for scalable apps

- **One `<Toaster>` per app**, mounted at the root. Never nest providers.
- **Drive updates by `id`** for progress/promise toasts: `const id = toast.loading(...)` then
  `toast.success(msg, { id })` mutates in place instead of stacking a new card.
- **Keep copy terse** — title is the action/result, description is the detail. Match the
  OfferBerries content rules (sentence case, `PKR 1,234`, fixed status vocabulary).
- **Don't toast validation errors** that belong inline on a form field.
- **Cap concurrent toasts** with `visibleToasts` (default 3) so the stack never clutters.
- **Extend, don't fork**: add a new variant by adding a key to `toast-variants.ts` and a branch in
  `Toast.tsx` — the API and motion come for free.

## Tailwind token bridge

```ts
// tailwind.config.ts → theme.extend.colors
colors: {
  canvas: "var(--bg-canvas)",
  page: "var(--bg-page)",
  border: "var(--border-default)",
  fg: { DEFAULT: "var(--text-primary)", muted: "var(--text-muted)", secondary: "var(--text-secondary)" },
  success: { DEFAULT: "var(--success)", bg: "var(--success-bg)", fg: "var(--success-text)" },
  danger:  { DEFAULT: "var(--danger)",  bg: "var(--danger-bg)",  fg: "var(--danger-text)" },
  warning: { DEFAULT: "var(--warning)", bg: "var(--warning-bg)", fg: "var(--warning-text)" },
  info:    { DEFAULT: "var(--info)",    bg: "var(--info-bg)",    fg: "var(--info-text)" },
},
borderRadius: { "2xl": "18px" },
```
