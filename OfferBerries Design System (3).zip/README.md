# OfferBerries ERP — Design System

A multi-module enterprise resource planning suite for Pakistani ecommerce marketplace operations. The product is desktop‑first, data‑dense, and built on a precise grid with a persistent dark sidebar and module‑coded accent gradients.

> **Design DNA:** Linear's typographic precision · Zelt's HR‑SaaS warmth · Supabase's dark, monospace‑friendly finance tables.

---

## Product overview

OfferBerries ERP is an internal operations platform — not a customer storefront. It is organized around **five top‑level modules**:

| Module                 | Accent gradient        | Surface tint    | Primary purpose                                |
| ---------------------- | ---------------------- | --------------- | ---------------------------------------------- |
| My Workspace           | indigo (default)       | `#EEF2FF`       | Personal inbox, drafts, assigned tasks         |
| HR & Administration    | `#4F46E5 → #7C3AED`    | `#EEF2FF`       | Employees, leave, permissions, org tree        |
| Finance & Accounting   | `#0EA5E9 → #10B981`    | `#F0F9FF`       | Salaries, breakups, account statements         |
| Business Operations    | `#F97316 → #F59E0B`    | `#FFF7ED`       | Sellers, bidders, marketplace ops              |
| Corporate Governance   | slate/emerald          | `#F8FAFC`       | Audit, policy, compliance                      |

Each module owns a colored gradient strip on its dashboard header and an accent that propagates to its primary button, badge, and stat icon. Layout chrome (sidebar, topbar, tables, cards) stays neutral — the colour comes from the module the user is *in*, never from decoration.

## Sources

This design system was reverse‑engineered from a real codebase:

- **GitHub:** [`IhsanKhann/Backend-offerB`](https://github.com/IhsanKhann/Backend-offerB) — React 19 + Vite + Tailwind 3 frontend with shadcn‑ui, Radix, lucide‑react, framer‑motion, Redux Toolkit. The full token system lives at `frontend/src/styles/tokens.css`; the Tailwind theme is a 1:1 mapping at `frontend/tailwind.config.js`.
- Module pages under `frontend/src/Pages/{hr,finance,business-ops,auth}/` informed the table, form, and dashboard patterns.

If you have access, browse those folders to extend this system — the table density and badge taxonomy in particular are deeper than what's previewed here.

---

## Content fundamentals

OfferBerries is a back‑office tool. Copy is functional, **terse, and noun‑heavy**. The product never markets to its own user.

- **Voice:** third‑person about records ("Employee suspended", "Statement paid"), imperative in actions ("Approve", "Reject draft", "Run payroll"). No "we", rarely "you" outside of empty states ("You have no pending approvals").
- **Casing:** Sentence case for everything except: section labels and table headers (UPPERCASE, 11px, +0.07em tracking) and status badges (Title Case — *Approved*, *Pending*, *Rejected*).
- **Numbers:** Always grouped — `PKR 1,250,000`. Currency prefixed with the ISO code, never the symbol. Dates are `DD MMM YYYY` (`08 May 2026`); times are 24‑hour for logs, 12‑hour for human‑facing UI.
- **Status taxonomy is fixed:** Approved, Pending, Rejected, Draft, Suspended, Blocked, Terminated, Paid, Restored. Don't invent new states; map to one of these.
- **Empty states** carry a single sentence + a single primary action. No illustrations, no jokes.
- **Emoji:** never. Flags for country/currency are acceptable inside cells; everything else is lucide‑react.
- **Tone examples:**
  - ✅ "3 leave requests awaiting your approval"
  - ✅ "Statement #ST‑2419 paid · PKR 84,500"
  - ❌ "Looks like you're all caught up! 🎉"
  - ❌ "Oops — something went wrong"

---

## Visual foundations

### Typography
- **Family:** Plus Jakarta Sans (400 regular, 500 medium). Mono is JetBrains Mono for IDs, codes, money columns.
- **Weights are restricted to 400 and 500.** No 600/700 in body. Section labels rely on tracking + caps, not weight.
- **Scale** (px / line‑height):
  `2xs 11/16 +0.07em caps` · `xs 12/18` · `sm 13/20` · `base 14/22` · `md 15/24` · `lg 16/26` · `xl 20/28` · `2xl 24/32` · `3xl 28/36` · `display 32/40`.
- Page titles are 32px medium; KPI numbers are 28–32px medium. Table cells default to 13px.

### Color
- **Sidebar is always `#0F172A`** (deeper `#080C14` in dark mode). It never themes to the active module.
- **Page canvas:** `#F8FAFC`. **Cards:** `#FFFFFF` with `#E2E8F0` 1px border and `--shadow-sm` on hover.
- **Text:** primary `#0F172A`, secondary `#475569`, muted `#94A3B8`, placeholder `#CBD5E1`.
- **Module gradients are 135°** (145° on dashboard hero strips). Hover dims the gradient by `opacity: 0.88`, never tints the colour.
- **Status badges** use a 9‑variant taxonomy with paired bg/text/border tokens — see `--badge-*` in `colors_and_type.css`.

### Spacing & geometry
- **4px grid**, named 1–20 (`--space-1` = 4px ... `--space-20` = 80px). Card padding is 20–24px; section gap is 24px; page gutter is 24px (16 on mobile).
- **Sidebar:** 228px expanded, 56px collapsed.  **Topbar:** 58px.
- **Radii:** xs 4, sm 6, md 10 (buttons/inputs), lg 14 (cards), xl 18 (module cards), 2xl 22 (modals).
- **Borders are 1px** for cards, **1.5px** for inputs and outline buttons so focus rings sit cleanly.

### Shadows
Five layered shadows, all `rgba(15,23,42,…)` so they never look grey on the warm whites:
`xs` 1+3px · `sm` 3+12px (default card hover) · `md` 6+24px · `lg` 16+40px (dropdowns, popovers) · `xl` 40+40px (modals).
Focus ring is `0 0 0 3px rgba(99,102,241,.15)` and has module‑specific variants (`focus-fin`, `focus-ops`).

### Motion
- Two easings: `cubic-bezier(0.4, 0, 0.2, 1)` for everything; `cubic-bezier(0.34, 1.56, 0.64, 1)` for modal/popover entrance only.
- Durations: `120ms` (hover/press), `200ms` (state transitions), `320ms` (sidebar collapse, drawer), `400ms` (spring).
- **No parallax. No scroll‑triggered animation. No bouncing icons.** Skeleton shimmer is a 1.5s linear sweep.

### Hover & press
- Buttons: opacity 0.88 + small shadow bump on hover; `scale(0.97)` on press.
- Rows: bg fades to `--bg-subtle` (`#F1F5F9`). No row shadow.
- Module cards: `translateY(-3px)` + `--shadow-md` on hover; settle to `translateY(-1px) scale(0.99)` on press.

### Backgrounds & imagery
- **No hero illustrations, no photography in‑chrome.** Avatars are initials on a tinted indigo circle.
- The only "decoration" is two soft white circles inside module gradient cards (`::before` and `::after` overlays) — that's it.
- Dark mode darkens surfaces and module tints; gradients stay the same hex.

### Layout
- Desktop‑first: 1280–1920px is the design target. The sidebar collapses below 1024px (transforms off‑canvas with overlay).
- Page max width is **1400px** centered; tables can stretch full width inside that.
- Cards align to a 12‑column grid inside the page with 24px gutters. KPI rows are 4‑up at xl, 2‑up at md.

---

## Iconography

- **Library:** [lucide‑react](https://lucide.dev) (pinned in `package.json`). Default size 14–16px in chrome, 18–20px in module cards, 13px inside the sidebar tree.
- **Stroke‑style only.** Never mix filled and stroked icons in one row. Stroke is lucide default (2px).
- Action icons sit on a 36×36 `erp-btn-icon` square with `--bg-subtle` fill.
- The sidebar's org tree uses `Building2` for branches and `Users` for leaves — color comes from the department (HR indigo, Finance sky, Ops orange, IT cyan, Compliance amber).
- **Emoji are never used.** Country flags in seller rows are acceptable as inline SVG, not unicode.
- A small set of brand glyphs (the `Layers` icon as the app mark inside a gradient‑filled 30×30 rounded square) stands in for the OfferBerries logo. No standalone wordmark exists in the codebase yet — flagged below.

---

## Index

```
README.md                  ← this file
SKILL.md                   ← Agent Skill manifest
colors_and_type.css        ← THE source of truth: all tokens (colors, type, spacing, shadows, components)
fonts/                     ← Plus Jakarta Sans + JetBrains Mono (loaded via Google Fonts in HTML)
preview/                   ← Design system cards (rendered in the Design System tab)
ui_kits/erp-app/           ← React UI kit (sidebar, topbar, tables, forms, dashboard)
  index.html               ← Interactive demo: switch modules, open modals, see toasts
  Sidebar.jsx, Topbar.jsx, …
frontend/                  ← Subset of the original codebase, kept for reference
```

---

## Caveats / known substitutions

- **No logo file exists in the source repo.** The "OfferBerries" mark is rendered as a gradient‑filled `Layers` glyph. Please drop a real logo SVG into `assets/` to replace it.
- **Plus Jakarta Sans & JetBrains Mono** are loaded from Google Fonts CDN. If you need them packaged, add `.woff2` files into `fonts/` and update the `@font-face` block at the top of `colors_and_type.css`.
- **Corporate Governance** module's accent (slate/emerald) is implied by the brief but not present in the codebase; treated as a neutral slate with an emerald accent badge in this system.
- **Empty‑state, modal, toast, and skeleton patterns** are documented as tokens + utility classes but the codebase imports MUI/Radix for the live components. The UI kit recreates the visual shell only.
